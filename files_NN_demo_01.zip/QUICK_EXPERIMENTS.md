# 🚀 Neural Network Demo - Quick Experiments Cheat Sheet

## ⚡ 5-Minute Experiments

### 1. Too Few Hidden Neurons (WILL FAIL!)
```python
nn = SimpleNeuralNetwork(input_size=2, hidden_size=1, output_size=1)
nn.train(X, y, epochs=10000, learning_rate=0.5)
# ❌ Won't reach 100% - not enough capacity!
```

### 2. Too Many Hidden Neurons (OVERKILL)
```python
nn = SimpleNeuralNetwork(input_size=2, hidden_size=20, output_size=1)
nn.train(X, y, epochs=10000, learning_rate=0.5)
# ✅ Works but unnecessary - wastes computation
```

### 3. Very High Learning Rate (UNSTABLE)
```python
nn = SimpleNeuralNetwork(input_size=2, hidden_size=4, output_size=1)
nn.train(X, y, epochs=10000, learning_rate=5.0)
# ⚠️ Loss might bounce around, never converge
```

### 4. Very Low Learning Rate (TOO SLOW)
```python
nn = SimpleNeuralNetwork(input_size=2, hidden_size=4, output_size=1)
nn.train(X, y, epochs=10000, learning_rate=0.01)
# 🐌 Takes forever to learn - might not finish in 10k epochs
```

### 5. Different Problem: AND Gate (EASIER!)
```python
# Replace XOR data with AND gate
y = np.array([[0], [0], [0], [1]])  # Only [1,1] → 1
nn.train(X, y, epochs=10000, learning_rate=0.5)
# ✅ Learns much faster! Linearly separable
```

### 6. Different Problem: OR Gate (ALSO EASIER!)
```python
y = np.array([[0], [1], [1], [1]])  # Any 1 → 1
nn.train(X, y, epochs=10000, learning_rate=0.5)
# ✅ Also learns quickly
```

---

## 📊 Expected Results Table

| Experiment | Hidden Neurons | Learning Rate | Expected Outcome |
|------------|---------------|---------------|------------------|
| **Baseline** | 4 | 0.5 | ✅ 100% accuracy, smooth learning |
| Too few | 1 | 0.5 | ❌ ~75% stuck, can't learn fully |
| Too many | 20 | 0.5 | ✅ 100% but slower, overkill |
| High LR | 4 | 5.0 | ⚠️ Unstable, might not converge |
| Low LR | 4 | 0.01 | 🐌 Very slow, needs more epochs |
| AND gate | 4 | 0.5 | ✅ Faster than XOR (linear!) |
| OR gate | 4 | 0.5 | ✅ Faster than XOR (linear!) |

---

## 🎯 Challenge: Find the Minimum

**Goal**: What's the smallest network that can solve XOR?

```python
# Try each of these:
hidden_size=1  # ❌ Too small
hidden_size=2  # 🤔 Might work sometimes
hidden_size=3  # ✅ Usually works
hidden_size=4  # ✅ Reliable (current default)
```

**Question**: Why is 2 neurons sometimes enough, but not always?  
**Answer**: Random weight initialization! Sometimes you get lucky.

---

## 🔬 Advanced: Modify Activation Function

Find this in the code:
```python
def sigmoid(self, x):
    return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
```

Try ReLU instead:
```python
def relu(self, x):
    return np.maximum(0, x)

def relu_derivative(self, x):
    return (x > 0).astype(float)
```

Then change:
- `self.a1 = self.sigmoid(self.z1)` → `self.a1 = self.relu(self.z1)`
- `self.sigmoid_derivative(self.a1)` → `self.relu_derivative(self.a1)`

**Warning**: Keep sigmoid on output layer! (Need values 0-1)

---

## 🐛 Quick Debugging Guide

### Problem: "Stuck at 50% accuracy"
```python
# Solution 1: Run again (new random weights)
np.random.seed(None)  # Remove fixed seed

# Solution 2: More hidden neurons
hidden_size=6

# Solution 3: Adjust learning rate
learning_rate=0.3
```

### Problem: "Loss exploding (getting bigger!)"
```python
# Solution: Lower learning rate
learning_rate=0.1
```

### Problem: "Takes too long"
```python
# Solution 1: Fewer epochs
epochs=5000

# Solution 2: Higher learning rate (but not too high!)
learning_rate=1.0
```

---

## 📈 What Good Training Looks Like

### Loss Curve Should:
✅ Start high (~0.25)  
✅ Decrease smoothly  
✅ Drop sharply around epoch 4000-6000  
✅ Flatten near 0.003 at the end  

### Decision Boundary Should:
✅ Separate green and red diagonally  
✅ Have smooth color transitions  
✅ Place all 4 training points in correct regions  

### Predictions Table Should:
✅ All have checkmarks ✅  
✅ Match expected outputs exactly  

---

## 🎮 Make It A Game!

### Competition Ideas:

1. **Speed Run**: Who can get 100% accuracy with fewest epochs?
2. **Minimalist**: Smallest network (fewest hidden neurons) that works
3. **Stability**: Best learning rate that never fails across 10 runs
4. **Architect**: Design a network for 3-input XOR (harder!)

---

## 💾 Save Your Experiments

```python
# At end of main(), add:
results = {
    'hidden_size': 4,
    'learning_rate': 0.5,
    'final_accuracy': accuracy,
    'final_loss': nn.loss_history[-1],
    'epochs_to_90pct': next(i for i, acc in enumerate(accuracy_history) if acc >= 90)
}

import json
with open('experiment_results.json', 'w') as f:
    json.dump(results, f, indent=2)
```

---

## 🧪 3-Input XOR Challenge (Advanced!)

```python
# 3-input XOR: Output 1 if odd number of 1s
X = np.array([
    [0, 0, 0],  # → 0 (zero 1s)
    [0, 0, 1],  # → 1 (one 1)
    [0, 1, 0],  # → 1 (one 1)
    [0, 1, 1],  # → 0 (two 1s)
    [1, 0, 0],  # → 1 (one 1)
    [1, 0, 1],  # → 0 (two 1s)
    [1, 1, 0],  # → 0 (two 1s)
    [1, 1, 1],  # → 1 (three 1s)
])

y = np.array([[0], [1], [1], [0], [1], [0], [0], [1]])

# Need more hidden neurons!
nn = SimpleNeuralNetwork(input_size=3, hidden_size=8, output_size=1)
```

---

## 📚 Homework Assignment Template

**Assignment**: Train a network to solve _________ [problem]

**Requirements**:
- [ ] Achieve ≥95% accuracy
- [ ] Loss below 0.01
- [ ] Train in under 10,000 epochs
- [ ] Use ≤6 hidden neurons
- [ ] Submit loss curve plot
- [ ] Explain why your architecture worked

**Bonus**:
- [ ] Find minimum number of hidden neurons
- [ ] Compare different learning rates
- [ ] Try a different activation function

---

## ✅ Quick Checklist: "Did I Understand?"

After this demo, can you:

- [ ] Explain why XOR needs a hidden layer?
- [ ] Draw the network architecture?
- [ ] Predict what happens with more/fewer neurons?
- [ ] Interpret a loss curve?
- [ ] Modify learning rate appropriately?
- [ ] Change the problem (AND/OR/NAND)?
- [ ] Debug when training fails?

If yes to all → **Ready for next level!** 🎓

---

**Print this out** and use it as reference while experimenting!
