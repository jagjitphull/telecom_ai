"""
🧠 SIMPLE NEURAL NETWORK DEMO - XOR Problem
==============================================
Perfect for beginners to understand:
- How neural networks learn
- Why we need hidden layers
- What backpropagation does
- How weights change during training

The XOR Problem: A classic that requires a hidden layer!
Input: Two binary values (0 or 1)
Output: 1 if inputs are different, 0 if same

   Input 1  Input 2  →  Output
   0        0        →  0
   0        1        →  1
   1        0        →  1
   1        1        →  0

A single layer can't solve this! We need a hidden layer.
"""

import numpy as np
import matplotlib.pyplot as plt

# Set random seed for reproducibility
np.random.seed(42)

# ===================================================================
#                    NEURAL NETWORK CLASS
# ===================================================================

class SimpleNeuralNetwork:
    """
    A simple 2-layer neural network (1 hidden layer)
    Architecture: 2 inputs → 4 hidden neurons → 1 output
    """
    
    def __init__(self, input_size=2, hidden_size=4, output_size=1):
        """Initialize network with random weights"""
        # Weights from input to hidden layer (2x4)
        self.W1 = np.random.randn(input_size, hidden_size) * 0.5
        self.b1 = np.zeros((1, hidden_size))
        
        # Weights from hidden to output layer (4x1)
        self.W2 = np.random.randn(hidden_size, output_size) * 0.5
        self.b2 = np.zeros((1, output_size))
        
        # Store training history
        self.loss_history = []
    
    def sigmoid(self, x):
        """Activation function: Squashes values between 0 and 1"""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
    
    def sigmoid_derivative(self, x):
        """Derivative of sigmoid for backpropagation"""
        return x * (1 - x)
    
    def forward(self, X):
        """
        Forward pass: Calculate predictions
        
        Steps:
        1. Input → Hidden Layer (with sigmoid activation)
        2. Hidden → Output (with sigmoid activation)
        """
        # Hidden layer
        self.z1 = np.dot(X, self.W1) + self.b1  # Linear combination
        self.a1 = self.sigmoid(self.z1)          # Activation
        
        # Output layer
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.a2 = self.sigmoid(self.z2)
        
        return self.a2
    
    def backward(self, X, y, output, learning_rate=0.5):
        """
        Backward pass: Update weights using gradient descent
        
        This is where the "learning" happens!
        """
        m = X.shape[0]  # Number of examples
        
        # Calculate error at output
        output_error = output - y
        output_delta = output_error * self.sigmoid_derivative(output)
        
        # Calculate error at hidden layer (backpropagate)
        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(self.a1)
        
        # Update weights and biases
        self.W2 -= learning_rate * self.a1.T.dot(output_delta) / m
        self.b2 -= learning_rate * np.sum(output_delta, axis=0, keepdims=True) / m
        self.W1 -= learning_rate * X.T.dot(hidden_delta) / m
        self.b1 -= learning_rate * np.sum(hidden_delta, axis=0, keepdims=True) / m
    
    def train(self, X, y, epochs=10000, learning_rate=0.5, verbose=True):
        """
        Train the network
        
        Args:
            X: Input data
            y: Target outputs
            epochs: Number of training iterations
            learning_rate: How big of steps to take when updating weights
            verbose: Print progress
        """
        for epoch in range(epochs):
            # Forward pass
            output = self.forward(X)
            
            # Calculate loss (Mean Squared Error)
            loss = np.mean((output - y) ** 2)
            self.loss_history.append(loss)
            
            # Backward pass
            self.backward(X, y, output, learning_rate)
            
            # Print progress
            if verbose and (epoch % 1000 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch:5d} | Loss: {loss:.6f} | Accuracy: {self.calculate_accuracy(X, y):.1f}%")
    
    def predict(self, X):
        """Make predictions (round to 0 or 1)"""
        return np.round(self.forward(X))
    
    def calculate_accuracy(self, X, y):
        """Calculate accuracy percentage"""
        predictions = self.predict(X)
        return 100 * np.mean(predictions == y)


# ===================================================================
#                    VISUALIZATION FUNCTIONS
# ===================================================================

def plot_training_progress(nn, X, y):
    """Create comprehensive visualization of training results"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('🧠 Neural Network Training Results - XOR Problem', 
                 fontsize=16, fontweight='bold')
    
    # 1. Loss over time
    ax1 = axes[0, 0]
    ax1.plot(nn.loss_history, color='#667eea', linewidth=2)
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss (MSE)')
    ax1.set_title('📉 Training Loss Over Time')
    ax1.grid(True, alpha=0.3)
    ax1.set_yscale('log')  # Log scale to see details
    
    # 2. Decision boundary
    ax2 = axes[0, 1]
    
    # Create a mesh to plot decision boundary
    x_min, x_max = -0.5, 1.5
    y_min, y_max = -0.5, 1.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                         np.linspace(y_min, y_max, 200))
    
    # Predict for each point in the mesh
    Z = nn.forward(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot decision boundary
    contour = ax2.contourf(xx, yy, Z, levels=20, cmap='RdYlGn', alpha=0.8)
    plt.colorbar(contour, ax=ax2, label='Network Output')
    
    # Plot training points
    colors = ['red' if label == 0 else 'green' for label in y.flatten()]
    ax2.scatter(X[:, 0], X[:, 1], c=colors, s=300, edgecolors='black', 
                linewidths=2, alpha=0.9, zorder=3)
    
    # Annotate points
    for i, (x, label) in enumerate(zip(X, y.flatten())):
        ax2.annotate(f'({int(x[0])},{int(x[1])})→{int(label)}', 
                    xy=x, xytext=(5, 5), textcoords='offset points',
                    fontsize=10, fontweight='bold')
    
    ax2.set_xlabel('Input 1')
    ax2.set_ylabel('Input 2')
    ax2.set_title('🎯 Decision Boundary (Green=1, Red=0)')
    ax2.set_xlim(x_min, x_max)
    ax2.set_ylim(y_min, y_max)
    ax2.grid(True, alpha=0.3)
    
    # 3. Network architecture visualization
    ax3 = axes[1, 0]
    ax3.axis('off')
    ax3.set_xlim(0, 10)
    ax3.set_ylim(0, 10)
    
    # Draw network structure
    # Input layer
    input_y = [7, 3]
    for i, y_pos in enumerate(input_y):
        circle = plt.Circle((2, y_pos), 0.5, color='#667eea', ec='black', linewidth=2)
        ax3.add_patch(circle)
        ax3.text(2, y_pos, f'I{i+1}', ha='center', va='center', 
                fontweight='bold', color='white')
    
    # Hidden layer
    hidden_y = [8, 6, 4, 2]
    for i, y_pos in enumerate(hidden_y):
        circle = plt.Circle((5, y_pos), 0.5, color='#764ba2', ec='black', linewidth=2)
        ax3.add_patch(circle)
        ax3.text(5, y_pos, f'H{i+1}', ha='center', va='center', 
                fontweight='bold', color='white')
    
    # Output layer
    circle = plt.Circle((8, 5), 0.5, color='#28a745', ec='black', linewidth=2)
    ax3.add_patch(circle)
    ax3.text(8, 5, 'O', ha='center', va='center', fontweight='bold', color='white')
    
    # Draw connections
    for in_y in input_y:
        for hid_y in hidden_y:
            ax3.plot([2.5, 4.5], [in_y, hid_y], 'gray', alpha=0.3, linewidth=1)
    
    for hid_y in hidden_y:
        ax3.plot([5.5, 7.5], [hid_y, 5], 'gray', alpha=0.3, linewidth=1)
    
    ax3.text(5, 9.5, '🏗️ Network Architecture', ha='center', fontsize=12, fontweight='bold')
    ax3.text(5, 0.5, '2 Inputs → 4 Hidden → 1 Output', ha='center', fontsize=10)
    
    # 4. Predictions table
    ax4 = axes[1, 1]
    ax4.axis('tight')
    ax4.axis('off')
    
    predictions = nn.predict(X)
    
    table_data = []
    table_data.append(['Input 1', 'Input 2', 'Expected', 'Predicted', 'Correct?'])
    
    for i, (x, y_true, y_pred) in enumerate(zip(X, y, predictions)):
        correct = '✅' if y_true == y_pred else '❌'
        table_data.append([
            str(int(x[0])), 
            str(int(x[1])), 
            str(int(y_true[0])),
            str(int(y_pred[0])),
            correct
        ])
    
    table = ax4.table(cellText=table_data, cellLoc='center', loc='center',
                      colWidths=[0.15, 0.15, 0.15, 0.15, 0.15])
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 2.5)
    
    # Style header row
    for i in range(5):
        table[(0, i)].set_facecolor('#667eea')
        table[(0, i)].set_text_props(weight='bold', color='white')
    
    # Style data rows
    for i in range(1, 5):
        for j in range(5):
            if j == 4:  # Correct? column
                if table_data[i][4] == '✅':
                    table[(i, j)].set_facecolor('#d4edda')
                else:
                    table[(i, j)].set_facecolor('#f8d7da')
            else:
                table[(i, j)].set_facecolor('#f8f9fa' if i % 2 == 0 else 'white')
    
    ax4.set_title('📊 Predictions vs Expected', fontsize=12, fontweight='bold', pad=20)
    
    plt.tight_layout()
    return fig


# ===================================================================
#                    MAIN DEMONSTRATION
# ===================================================================

def main():
    print("=" * 70)
    print("🧠 NEURAL NETWORK DEMO - XOR PROBLEM")
    print("=" * 70)
    print()
    
    # XOR dataset
    print("📊 Training Data (XOR Problem):")
    print("-" * 40)
    X = np.array([[0, 0],
                  [0, 1],
                  [1, 0],
                  [1, 1]])
    
    y = np.array([[0],
                  [1],
                  [1],
                  [0]])
    
    for i, (inputs, output) in enumerate(zip(X, y)):
        print(f"   Input: {inputs} → Output: {output[0]}")
    print()
    
    # Create and train network
    print("🏗️  Building Neural Network...")
    print("   Architecture: 2 inputs → 4 hidden neurons → 1 output")
    print()
    
    nn = SimpleNeuralNetwork(input_size=2, hidden_size=4, output_size=1)
    
    print("🎓 Training...")
    print("-" * 40)
    nn.train(X, y, epochs=10000, learning_rate=0.5, verbose=True)
    print()
    
    # Final results
    print("=" * 70)
    print("✅ TRAINING COMPLETE!")
    print("=" * 70)
    print()
    
    print("📊 Final Test Results:")
    print("-" * 40)
    predictions = nn.predict(X)
    for i, (inputs, expected, predicted) in enumerate(zip(X, y, predictions)):
        status = "✅" if expected == predicted else "❌"
        print(f"   Input: {inputs} → Expected: {int(expected[0])}, "
              f"Predicted: {int(predicted[0])} {status}")
    
    accuracy = nn.calculate_accuracy(X, y)
    print()
    print(f"🎯 Final Accuracy: {accuracy:.1f}%")
    print()
    
    # Visualizations
    print("📈 Generating visualizations...")
    fig = plot_training_progress(nn, X, y)
    
    # Save figure
    plt.savefig('/mnt/user-data/outputs/nn_training_results.png', 
                dpi=150, bbox_inches='tight')
    print("   ✅ Saved: nn_training_results.png")
    
    plt.show()
    
    print()
    print("=" * 70)
    print("🎉 Demo Complete!")
    print()
    print("💡 Key Learnings:")
    print("   1. Neural networks learn through repeated adjustments (epochs)")
    print("   2. Hidden layers are needed for non-linear patterns (like XOR)")
    print("   3. Loss decreases as the network learns")
    print("   4. Decision boundaries show what the network learned")
    print("=" * 70)


if __name__ == "__main__":
    main()
