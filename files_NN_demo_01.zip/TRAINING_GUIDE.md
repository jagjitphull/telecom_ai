# 🧠 Neural Network Training Demo - Complete Guide

## 📚 What is This?

This is a **hands-on demonstration** of how neural networks learn, using the classic **XOR problem** - a perfect example for beginners because:

✅ Simple to understand (only 4 data points)  
✅ Impossible for single-layer networks (proves we need hidden layers!)  
✅ Visual results (you can SEE what the network learned)  
✅ Fast training (completes in seconds)

---

## 🎯 The XOR Problem Explained

**XOR (Exclusive OR)** returns `1` when inputs are different, `0` when they're the same:

```
Input 1  Input 2  →  Output
   0        0     →    0      (Same → 0)
   0        1     →    1      (Different → 1)
   1        0     →    1      (Different → 1)
   1        1     →    0      (Same → 0)
```

**Why is this hard?**  
You can't draw a single straight line to separate the outputs! This requires a **hidden layer**.

---

## 🚀 How to Run

### Prerequisites
```bash
pip install numpy matplotlib
```

### Run the Demo
```bash
python3 simple_nn_demo.py
```

### What You'll See
1. **Training progress** - Loss decreasing over 10,000 epochs
2. **Final accuracy** - Should reach 100%
3. **Visualization** - 4 plots showing how the network learned

---

## 📊 Understanding the Visualizations

### 1. Training Loss Over Time (Top Left)
- **Y-axis**: Error (how wrong the network is)
- **What to look for**: 
  - Loss should **decrease** over time (network is learning!)
  - Around epoch 5000, it drops sharply (the "aha!" moment)
  - Eventually flattens near zero (learned the pattern)

### 2. Decision Boundary (Top Right)
- **Green regions**: Network predicts 1
- **Red regions**: Network predicts 0
- **What to look for**:
  - Green and red should be separated diagonally
  - The 4 training points should be in their correct colored regions
  - This shows the network learned the XOR pattern!

### 3. Network Architecture (Bottom Left)
- **Blue circles**: Input neurons (2)
- **Purple circles**: Hidden neurons (4)
- **Green circle**: Output neuron (1)
- **Gray lines**: Connections (weights)

### 4. Predictions Table (Bottom Right)
- Shows exact predictions vs expected outputs
- All should have ✅ checkmarks when trained

---

## 🎓 Key Concepts to Teach

### 1. Forward Propagation
```python
# Data flows INPUT → HIDDEN → OUTPUT
Input [0,1] → Hidden Layer → Output [1]
```

### 2. Backward Propagation
```python
# Errors flow backward to update weights
Output Error → Hidden Layer Error → Update Weights
```

### 3. Learning Rate
- **Too high** (e.g., 5.0): Network bounces around, never settles
- **Too low** (e.g., 0.01): Learns very slowly
- **Just right** (0.5): Converges smoothly

### 4. Why Hidden Layers?
**Experiment**: Remove the hidden layer!
- Change `hidden_size=4` to `hidden_size=0` in the code
- Watch it fail! It can't learn XOR without a hidden layer

---

## 🔬 Hands-On Exercises for Trainees

### Exercise 1: Change the Architecture
**Current**: 2 → 4 → 1

Try these and observe the effects:
```python
# Fewer hidden neurons (might fail!)
nn = SimpleNeuralNetwork(input_size=2, hidden_size=2, output_size=1)

# More hidden neurons (overkill but will work)
nn = SimpleNeuralNetwork(input_size=2, hidden_size=8, output_size=1)

# Just enough
nn = SimpleNeuralNetwork(input_size=2, hidden_size=3, output_size=1)
```

**Question**: What's the minimum number of hidden neurons needed?

---

### Exercise 2: Adjust Learning Rate
```python
# Too slow
nn.train(X, y, epochs=10000, learning_rate=0.01)

# Too fast (might not converge!)
nn.train(X, y, epochs=10000, learning_rate=2.0)

# Optimal
nn.train(X, y, epochs=10000, learning_rate=0.5)
```

**Question**: What happens to the loss curve with each learning rate?

---

### Exercise 3: Reduce Training Time
```python
# Fewer epochs
nn.train(X, y, epochs=1000, learning_rate=0.5)
```

**Question**: Does it still reach 100% accuracy? What's the minimum epochs needed?

---

### Exercise 4: Change the Problem (Advanced!)

Replace the XOR data with AND gate:
```python
# AND gate (easier problem!)
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

y = np.array([[0],  # 0 AND 0 = 0
              [0],  # 0 AND 1 = 0
              [0],  # 1 AND 0 = 0
              [1]]) # 1 AND 1 = 1
```

**Question**: Does it train faster? Why? (Hint: AND is linearly separable!)

---

## 🎯 Expected Learning Outcomes

After this demo, trainees should understand:

1. ✅ **Neural networks learn by adjusting weights** over many iterations
2. ✅ **Hidden layers are necessary** for non-linear patterns
3. ✅ **Loss decreases** as the network learns (getting less wrong)
4. ✅ **Hyperparameters matter** (learning rate, epochs, architecture)
5. ✅ **Decision boundaries** show what the network learned visually

---

## 🐛 Troubleshooting

### "Network stuck at 50% accuracy"
- **Cause**: Bad random initialization or learning rate too high
- **Fix**: Run again (different random seed) or lower learning rate

### "Loss not decreasing"
- **Cause**: Learning rate too low or too few epochs
- **Fix**: Increase learning rate or train longer

### "ImportError: No module named 'matplotlib'"
- **Fix**: `pip install matplotlib`

---

## 🚀 Next Steps After This Demo

Once comfortable with XOR, progress to:

1. **More Complex Patterns**: Circles, spirals (need more data points)
2. **MNIST Digits**: Real-world handwriting recognition
3. **Different Activation Functions**: Try ReLU instead of sigmoid
4. **Deeper Networks**: Add more hidden layers
5. **Regularization**: Prevent overfitting on larger datasets

---

## 📝 Discussion Questions for Trainees

1. **Why does the network need ~5000 epochs** to suddenly "get it"?
2. **What would happen** if we only had 3 training examples?
3. **Can you explain** why a single line can't solve XOR?
4. **What real-world problems** are similar to XOR?
5. **How would you improve** this network for a harder problem?

---

## 💡 Pro Tips for Instructors

### Make it Interactive
- Let trainees **run multiple times** with different random seeds
- Have them **predict** what will happen before changing parameters
- Create a **competition**: "Smallest network that solves XOR"

### Common Misconceptions
- ❌ "More hidden neurons = always better" (No! Overfitting risk)
- ❌ "100% accuracy = perfect model" (Only on this tiny dataset!)
- ❌ "Neural networks are magic" (No! Just math + optimization)

### Visualization Tips
- Save the loss plot at different learning rates for comparison
- Animate the decision boundary evolving during training
- Show what happens with NO hidden layer (fails!)

---

## 📚 Additional Resources

### Concepts Covered
- Forward propagation
- Backpropagation
- Gradient descent
- Activation functions (Sigmoid)
- Loss functions (MSE)
- Network architecture

### Related Reading
- [Neural Networks and Deep Learning (Free Book)](http://neuralnetworksanddeeplearning.com/)
- [3Blue1Brown: Neural Network Videos](https://www.youtube.com/playlist?list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi)
- [Playground.tensorflow.org](https://playground.tensorflow.org/) - Interactive web demo

---

## 🎉 Success Criteria

Trainees successfully understand the demo when they can:

✅ Explain why hidden layers are needed  
✅ Predict how parameter changes affect training  
✅ Interpret the loss curve  
✅ Understand the decision boundary visualization  
✅ Modify the code to solve different problems  

---

**Questions? Issues?** Review the inline code comments - every function is documented!

**Ready for more?** Try modifying the network to solve a 3-input problem (3D visualization!)
