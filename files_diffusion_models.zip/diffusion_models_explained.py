"""
🎨 DIFFUSION MODELS EXPLAINED - Interactive Tutorial
=====================================================

This script demonstrates how diffusion models work with both:
1. Simple 2D data visualization (easy to understand)
2. Text sequence generation (experimental approach)

Key Concepts:
- Forward Process: Gradually add noise to data
- Reverse Process: Learn to denoise and generate new data
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Tuple, List
import warnings
warnings.filterwarnings('ignore')

print("=" * 70)
print("🎨 DIFFUSION MODELS: A Complete Tutorial")
print("=" * 70)


# ============================================================================
# PART 1: UNDERSTANDING THE CORE CONCEPT
# ============================================================================

class SimpleDiffusionModel:
    """
    A simplified diffusion model to understand the basic concepts.
    
    The Process:
    1. Forward Diffusion: Gradually add Gaussian noise to data
    2. Reverse Diffusion: Learn to predict and remove the noise
    """
    
    def __init__(self, num_timesteps: int = 100):
        """
        Args:
            num_timesteps: Number of diffusion steps (T)
        """
        self.num_timesteps = num_timesteps
        
        # Define noise schedule (beta values)
        # These control how much noise is added at each step
        self.betas = self._linear_beta_schedule()
        
        # Precompute useful values
        self.alphas = 1.0 - self.betas
        self.alphas_cumprod = np.cumprod(self.alphas)
        
        print(f"\n📊 Diffusion Model initialized with {num_timesteps} timesteps")
        print(f"   Beta range: {self.betas[0]:.6f} → {self.betas[-1]:.6f}")
    
    def _linear_beta_schedule(self) -> np.ndarray:
        """
        Linear schedule for noise levels.
        Starts small, ends large (more noise over time).
        """
        beta_start = 0.0001
        beta_end = 0.02
        return np.linspace(beta_start, beta_end, self.num_timesteps)
    
    def forward_diffusion(self, x0: np.ndarray, t: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Forward diffusion: Add noise to data at timestep t
        
        Formula: x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * noise
        
        Args:
            x0: Original data
            t: Timestep (0 to num_timesteps-1)
        
        Returns:
            noisy_data: Data with noise added
            noise: The actual noise that was added
        """
        # Generate random Gaussian noise
        noise = np.random.randn(*x0.shape)
        
        # Get cumulative product of alphas up to timestep t
        alpha_bar_t = self.alphas_cumprod[t]
        
        # Add noise according to the diffusion formula
        noisy_data = np.sqrt(alpha_bar_t) * x0 + np.sqrt(1 - alpha_bar_t) * noise
        
        return noisy_data, noise
    
    def visualize_forward_process(self, data_point: np.ndarray):
        """
        Visualize how noise is gradually added to a data point.
        """
        print("\n🔄 Demonstrating Forward Diffusion Process...")
        print("   (Adding noise step by step)\n")
        
        # Select timesteps to visualize
        timesteps_to_show = [0, 10, 25, 50, 75, 99]
        
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()
        
        for idx, t in enumerate(timesteps_to_show):
            noisy_data, noise = self.forward_diffusion(data_point, t)
            
            ax = axes[idx]
            
            # For 2D data, plot as scatter
            if data_point.ndim == 2:
                ax.scatter(noisy_data[:, 0], noisy_data[:, 1], alpha=0.6, s=20)
                ax.set_xlim(-4, 4)
                ax.set_ylim(-4, 4)
            else:
                ax.plot(noisy_data, alpha=0.7)
            
            alpha_bar = self.alphas_cumprod[t]
            noise_level = 1 - alpha_bar
            
            ax.set_title(f'Timestep {t}\nNoise Level: {noise_level:.3f}', fontsize=12)
            ax.grid(True, alpha=0.3)
            
            print(f"   Step {t:3d}: Noise level = {noise_level:.4f}")
        
        plt.suptitle('Forward Diffusion: Gradually Adding Noise', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig('/mnt/user-data/outputs/forward_diffusion_process.png', dpi=150, bbox_inches='tight')
        print("\n   ✅ Visualization saved!")
        
        return fig


# ============================================================================
# PART 2: DEMONSTRATE WITH 2D DATA (EASY TO VISUALIZE)
# ============================================================================

def create_sample_data(n_samples: int = 500) -> np.ndarray:
    """
    Create a simple 2D dataset (spiral pattern).
    """
    t = np.linspace(0, 4 * np.pi, n_samples)
    x = t * np.cos(t) * 0.3
    y = t * np.sin(t) * 0.3
    data = np.column_stack([x, y])
    
    # Add small amount of noise
    data += np.random.randn(*data.shape) * 0.1
    
    return data


def demonstrate_2d_diffusion():
    """
    Demonstrate diffusion process on 2D data.
    """
    print("\n" + "=" * 70)
    print("📍 PART 1: Diffusion on 2D Data (Visual Demo)")
    print("=" * 70)
    
    # Create sample data
    data = create_sample_data(300)
    print(f"\n✅ Created sample 2D data: {data.shape}")
    print(f"   Data range: X=[{data[:, 0].min():.2f}, {data[:, 0].max():.2f}], "
          f"Y=[{data[:, 1].min():.2f}, {data[:, 1].max():.2f}]")
    
    # Initialize diffusion model
    diffusion = SimpleDiffusionModel(num_timesteps=100)
    
    # Visualize the forward process
    diffusion.visualize_forward_process(data)
    
    return diffusion, data


# ============================================================================
# PART 3: TEXT DIFFUSION (SIMPLIFIED CONCEPT)
# ============================================================================

class TextDiffusionConcept:
    """
    Simplified concept of how diffusion could work with text/sequences.
    
    NOTE: This is a simplified educational example. Real text diffusion models
    are much more complex and not commonly used in production LLMs.
    """
    
    def __init__(self, vocab_size: int = 1000, embedding_dim: int = 64):
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.num_timesteps = 50
        
        # Create random embeddings for demonstration
        np.random.seed(42)
        self.embeddings = np.random.randn(vocab_size, embedding_dim) * 0.5
        
        print(f"\n📝 Text Diffusion Concept initialized")
        print(f"   Vocabulary size: {vocab_size}")
        print(f"   Embedding dimension: {embedding_dim}")
    
    def text_to_embeddings(self, token_ids: List[int]) -> np.ndarray:
        """Convert token IDs to embeddings."""
        return np.array([self.embeddings[tid] for tid in token_ids])
    
    def add_noise_to_embeddings(self, embeddings: np.ndarray, noise_level: float) -> np.ndarray:
        """
        Add noise to text embeddings (similar to forward diffusion).
        """
        noise = np.random.randn(*embeddings.shape) * noise_level
        noisy_embeddings = embeddings + noise
        return noisy_embeddings
    
    def demonstrate_text_diffusion(self):
        """
        Show how text embeddings get corrupted with noise.
        """
        print("\n🔄 Demonstrating Text Diffusion Concept...")
        
        # Simulate a sentence with 5 tokens
        sentence_tokens = [100, 250, 500, 750, 900]  # Random token IDs
        print(f"   Original tokens: {sentence_tokens}")
        
        # Get embeddings
        original_embeddings = self.text_to_embeddings(sentence_tokens)
        print(f"   Embedding shape: {original_embeddings.shape}")
        
        # Show noise at different levels
        noise_levels = [0.0, 0.2, 0.5, 1.0, 2.0]
        
        fig, axes = plt.subplots(1, 5, figsize=(20, 4))
        
        for idx, noise_level in enumerate(noise_levels):
            noisy_embeddings = self.add_noise_to_embeddings(original_embeddings, noise_level)
            
            # Visualize first 2 dimensions of embeddings
            ax = axes[idx]
            ax.scatter(original_embeddings[:, 0], original_embeddings[:, 1], 
                      c='blue', s=100, alpha=0.7, label='Original', marker='o')
            ax.scatter(noisy_embeddings[:, 0], noisy_embeddings[:, 1], 
                      c='red', s=100, alpha=0.7, label='Noisy', marker='x')
            
            ax.set_title(f'Noise Level: {noise_level}', fontsize=11)
            ax.legend()
            ax.grid(True, alpha=0.3)
            ax.set_xlim(-3, 3)
            ax.set_ylim(-3, 3)
            
            print(f"   Noise {noise_level:.1f}: MSE = {np.mean((original_embeddings - noisy_embeddings)**2):.4f}")
        
        plt.suptitle('Text Diffusion: Adding Noise to Token Embeddings', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig('/mnt/user-data/outputs/text_diffusion_concept.png', dpi=150, bbox_inches='tight')
        print("\n   ✅ Text diffusion visualization saved!")


# ============================================================================
# PART 4: KEY CONCEPTS EXPLANATION
# ============================================================================

def explain_key_concepts():
    """
    Print detailed explanation of diffusion model concepts.
    """
    print("\n" + "=" * 70)
    print("📚 KEY CONCEPTS IN DIFFUSION MODELS")
    print("=" * 70)
    
    concepts = {
        "Forward Diffusion (Noise Addition)": [
            "Gradually add Gaussian noise to clean data",
            "At each timestep t, data becomes more corrupted",
            "Formula: x_t = √(ᾱ_t) * x_0 + √(1 - ᾱ_t) * ε",
            "After many steps, data becomes pure noise",
        ],
        "Reverse Diffusion (Denoising)": [
            "Learn to reverse the noise process",
            "Train a neural network to predict the noise",
            "Start from random noise, gradually denoise",
            "Result: Generate new, realistic samples",
        ],
        "Noise Schedule (β_t)": [
            "Controls how much noise is added at each step",
            "Typically increases over time (linear or cosine)",
            "Small β at start, larger β at end",
            "Critical hyperparameter for model quality",
        ],
        "Training Objective": [
            "Learn to predict the noise that was added",
            "Loss = ||ε - ε_θ(x_t, t)||²",
            "ε: actual noise, ε_θ: predicted noise",
            "Trained across all timesteps",
        ],
        "Generation Process": [
            "Start with random Gaussian noise x_T",
            "Iteratively denoise: x_T → x_{T-1} → ... → x_0",
            "At each step, predict and subtract noise",
            "Final result x_0 is a new generated sample",
        ]
    }
    
    for concept, points in concepts.items():
        print(f"\n🔹 {concept}")
        for point in points:
            print(f"   • {point}")


# ============================================================================
# PART 5: DIFFUSION VS TRADITIONAL LLMs
# ============================================================================

def compare_with_llms():
    """
    Explain the difference between diffusion models and traditional LLMs.
    """
    print("\n" + "=" * 70)
    print("🔄 DIFFUSION MODELS vs TRADITIONAL LLMs")
    print("=" * 70)
    
    comparison = """
╔══════════════════════╦═══════════════════════════╦═══════════════════════════╗
║     ASPECT           ║    DIFFUSION MODELS       ║    TRADITIONAL LLMs       ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Primary Use          ║ Image Generation          ║ Text Generation           ║
║                      ║ (Stable Diffusion, DALL-E)║ (GPT, Claude, LLaMA)     ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Architecture         ║ U-Net (for images)        ║ Transformer               ║
║                      ║ Denoising Networks        ║ Attention Mechanisms      ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Generation Method    ║ Iterative Denoising       ║ Autoregressive            ║
║                      ║ (many steps)              ║ (token by token)          ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Training             ║ Predict noise in data     ║ Predict next token        ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Speed                ║ Slower (many steps)       ║ Faster (parallel)         ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ For Text?            ║ Experimental/Research     ║ Standard & Proven         ║
╠══════════════════════╬═══════════════════════════╬═══════════════════════════╣
║ Examples             ║ • Stable Diffusion        ║ • GPT-4, Claude           ║
║                      ║ • DALL-E 2                ║ • Gemini, LLaMA           ║
║                      ║ • Imagen                  ║ • BERT, T5                ║
╚══════════════════════╩═══════════════════════════╩═══════════════════════════╝

KEY INSIGHT:
• Diffusion models are GREAT for images, audio, video
• Traditional transformers are BETTER for text/language
• Some research explores diffusion for text, but it's not standard
"""
    print(comparison)


# ============================================================================
# PART 6: MATHEMATICAL FORMULAS
# ============================================================================

def show_mathematical_details():
    """
    Display the key mathematical formulas.
    """
    print("\n" + "=" * 70)
    print("🧮 MATHEMATICAL FORMULAS")
    print("=" * 70)
    
    formulas = """
1️⃣ FORWARD DIFFUSION (Adding Noise):
   
   q(x_t | x_{t-1}) = N(x_t; √(1-β_t) x_{t-1}, β_t I)
   
   Direct formula (skip to any timestep t):
   q(x_t | x_0) = N(x_t; √(ᾱ_t) x_0, (1-ᾱ_t) I)
   
   where: ᾱ_t = ∏_{i=1}^{t} (1 - β_i)


2️⃣ REVERSE DIFFUSION (Denoising):
   
   p_θ(x_{t-1} | x_t) = N(x_{t-1}; μ_θ(x_t, t), Σ_θ(x_t, t))
   
   The model learns to predict the mean μ_θ


3️⃣ TRAINING LOSS:
   
   L = E_{t, x_0, ε} [||ε - ε_θ(√(ᾱ_t) x_0 + √(1-ᾱ_t) ε, t)||²]
   
   Goal: Predict the noise ε that was added


4️⃣ NOISE SCHEDULE:
   
   Linear: β_t = β_min + (β_max - β_min) * (t / T)
   
   Cosine: ᾱ_t = cos²(π/2 * (t/T + s)/(1 + s))


5️⃣ SAMPLING (Generation):
   
   x_{t-1} = 1/√(α_t) * (x_t - (β_t/√(1-ᾱ_t)) * ε_θ(x_t, t)) + σ_t z
   
   where: z ~ N(0, I) is random noise
          σ_t controls stochasticity
"""
    print(formulas)


# ============================================================================
# PART 7: PRACTICAL EXAMPLE CODE
# ============================================================================

def show_practical_example():
    """
    Show a practical PyTorch-style implementation snippet.
    """
    print("\n" + "=" * 70)
    print("💻 PRACTICAL IMPLEMENTATION (PyTorch-style)")
    print("=" * 70)
    
    code = '''
# Simplified training loop for a diffusion model

import torch
import torch.nn as nn

class DiffusionModel(nn.Module):
    """Simple denoising network"""
    
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 128)
        )
    
    def forward(self, noisy_data, timestep):
        """Predict the noise"""
        # In practice, timestep is embedded and concatenated
        return self.network(noisy_data)

# Training
model = DiffusionModel()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

for epoch in range(num_epochs):
    for batch in dataloader:
        # 1. Sample random timestep
        t = torch.randint(0, num_timesteps, (batch_size,))
        
        # 2. Add noise (forward diffusion)
        noise = torch.randn_like(batch)
        noisy_batch = sqrt_alpha_bar[t] * batch + sqrt_one_minus_alpha_bar[t] * noise
        
        # 3. Predict the noise
        predicted_noise = model(noisy_batch, t)
        
        # 4. Compute loss
        loss = F.mse_loss(predicted_noise, noise)
        
        # 5. Backprop
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

# Generation (sampling)
x = torch.randn(batch_size, data_dim)  # Start from noise

for t in reversed(range(num_timesteps)):
    # Predict noise
    pred_noise = model(x, t)
    
    # Denoise one step
    x = denoise_step(x, pred_noise, t)

# x is now a generated sample!
'''
    print(code)


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Run the complete diffusion model tutorial.
    """
    print("\n🚀 Starting Interactive Diffusion Model Tutorial...")
    print("   This will create visualizations and explanations.\n")
    
    # Part 1: 2D Visualization
    diffusion, data = demonstrate_2d_diffusion()
    
    # Part 2: Text Diffusion Concept
    print("\n" + "=" * 70)
    print("📝 PART 2: Text Diffusion (Conceptual Demo)")
    print("=" * 70)
    text_diffusion = TextDiffusionConcept()
    text_diffusion.demonstrate_text_diffusion()
    
    # Part 3: Explanations
    explain_key_concepts()
    
    # Part 4: Comparison with LLMs
    compare_with_llms()
    
    # Part 5: Mathematical Details
    show_mathematical_details()
    
    # Part 6: Practical Code
    show_practical_example()
    
    # Summary
    print("\n" + "=" * 70)
    print("✅ TUTORIAL COMPLETE!")
    print("=" * 70)
    print("""
📁 Generated Files:
   • forward_diffusion_process.png - Shows noise being added step by step
   • text_diffusion_concept.png - Shows noise on text embeddings

🎯 Key Takeaways:
   1. Diffusion models work by gradually adding noise (forward)
   2. Then learning to remove noise (reverse)
   3. Great for images, but LLMs use different architectures for text
   4. Training goal: predict the noise that was added
   5. Generation: start from noise, iteratively denoise

📚 Next Steps:
   • Study Stable Diffusion for image generation
   • Explore DDPM (Denoising Diffusion Probabilistic Models)
   • Look into Score-based models
   • Compare with GANs and VAEs

💡 For Text Generation:
   • Stick with Transformer-based LLMs (GPT, Claude, etc.)
   • Diffusion for text is mostly research-level
""")


if __name__ == "__main__":
    main()
