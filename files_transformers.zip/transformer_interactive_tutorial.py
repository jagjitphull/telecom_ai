"""
🎓 Interactive Transformer Tutorial - Step by Step
===================================================

Run this to see each transformer component in action with real examples!
"""

import numpy as np
np.random.seed(42)


def print_section(title):
    """Print a formatted section header."""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70 + "\n")


def print_matrix(matrix, row_labels=None, col_labels=None, title="Matrix"):
    """Pretty print a matrix with labels."""
    print(f"\n{title}:")
    print("-" * 60)
    
    # Print column labels
    if col_labels:
        print("        ", end="")
        for label in col_labels:
            print(f"{label:>8}", end="")
        print()
    
    # Print matrix with row labels
    for i, row in enumerate(matrix):
        if row_labels:
            print(f"{row_labels[i]:>6} |", end="")
        else:
            print(f"Row {i:2} |", end="")
        
        for val in row:
            print(f"{val:8.3f}", end="")
        print()
    print()


# ============================================================================
# STEP 1: Understanding Embeddings
# ============================================================================

print_section("STEP 1: Word Embeddings")

print("💬 Input Sentence: 'The cat sat'")
print("\nIn LLMs, each word is converted to a vector of numbers (embedding).")
print("This vector captures the 'meaning' of the word.")

# Simple example with 4-dimensional embeddings
words = ["The", "cat", "sat"]
d_model = 4

# Create mock embeddings (in real LLMs, these are learned from data)
embeddings = {
    "The": np.array([0.1, 0.2, 0.1, 0.0]),
    "cat": np.array([0.5, 0.8, 0.2, 0.3]),
    "sat": np.array([0.3, 0.1, 0.9, 0.4])
}

print(f"\n📊 Embedding dimension: {d_model}")
print("\nWord Embeddings:")
for word in words:
    emb = embeddings[word]
    print(f"  '{word}': [{emb[0]:.1f}, {emb[1]:.1f}, {emb[2]:.1f}, {emb[3]:.1f}]")

print("\n💡 Key Insight:")
print("   Similar words have similar embedding vectors!")
print("   e.g., 'cat' and 'dog' would have similar vectors")


# ============================================================================
# STEP 2: Positional Encoding
# ============================================================================

print_section("STEP 2: Positional Encoding")

print("🤔 Problem: Transformers process all words at once (parallel)")
print("   How does it know word order?")
print("\n✅ Solution: Add position information to each embedding!")

# Simple positional encoding
def simple_positional_encoding(position, d_model):
    """Create a simple positional encoding."""
    pe = np.zeros(d_model)
    for i in range(d_model):
        if i % 2 == 0:
            pe[i] = np.sin(position / (10000 ** (i / d_model)))
        else:
            pe[i] = np.cos(position / (10000 ** (i / d_model)))
    return pe

print("\nAdding position information:")
for i, word in enumerate(words):
    pos_enc = simple_positional_encoding(i, d_model)
    emb_with_pos = embeddings[word] + pos_enc
    
    print(f"\nPosition {i} - '{word}':")
    print(f"  Original embedding:  {embeddings[word]}")
    print(f"  Position encoding:   {pos_enc}")
    print(f"  Final embedding:     {emb_with_pos}")

print("\n💡 Key Insight:")
print("   Now each word embedding contains BOTH meaning AND position!")


# ============================================================================
# STEP 3: Self-Attention (The Magic!)
# ============================================================================

print_section("STEP 3: Self-Attention Mechanism")

print("🎯 Goal: Let each word 'look at' other words to understand context")
print("\nExample: In 'The cat sat', the word 'sat' should pay attention to 'cat'")
print("         (to know WHO sat)")

# Create Q, K, V matrices (simplified)
X = np.array([embeddings[w] for w in words])  # (3, 4)

print("\n📝 Step 1: Create Query (Q), Key (K), Value (V) matrices")
print("   - Query: 'What am I looking for?'")
print("   - Key: 'What information do I have?'")
print("   - Value: 'What information do I provide?'")

# Simple projection matrices (normally learned)
W_q = np.random.randn(d_model, d_model) * 0.1
W_k = np.random.randn(d_model, d_model) * 0.1
W_v = np.random.randn(d_model, d_model) * 0.1

Q = X @ W_q
K = X @ W_k
V = X @ W_v

print(f"\n   Q shape: {Q.shape}, K shape: {K.shape}, V shape: {V.shape}")

print("\n📝 Step 2: Calculate attention scores")
print("   Score = Q × K^T / √d_model")
print("   This measures how much each word should attend to each other word")

scores = (Q @ K.T) / np.sqrt(d_model)
print_matrix(scores, words, words, "Attention Scores (before softmax)")

print("\n📝 Step 3: Apply softmax to get attention weights")
print("   Converts scores to probabilities (sum to 1.0)")

def softmax(x):
    exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)

attention_weights = softmax(scores)
print_matrix(attention_weights, words, words, "Attention Weights (probabilities)")

print("💡 Interpretation of the attention matrix:")
print("   Row = Query word (asking)")
print("   Column = Key word (being asked about)")
print("   Value = How much attention to pay")
print("\n   Each row sums to 1.0 (100% of attention distributed)")

print("\n📝 Step 4: Apply attention to values")
print("   Output = Attention_Weights × Values")

output = attention_weights @ V
print(f"\n   Output shape: {output.shape}")
print("\n   Each word now has a NEW representation that considers")
print("   the context of all other words!")

# Show one example in detail
word_idx = 1  # "cat"
print(f"\n🔍 Detailed example for '{words[word_idx]}':")
print(f"   This word attends to:")
for i, other_word in enumerate(words):
    weight = attention_weights[word_idx, i]
    print(f"      '{other_word}': {weight:.1%} of attention")


# ============================================================================
# STEP 4: Multi-Head Attention
# ============================================================================

print_section("STEP 4: Multi-Head Attention")

print("🎯 Idea: Run MULTIPLE attention mechanisms in parallel")
print("   Each 'head' can learn different types of relationships!")

num_heads = 2
print(f"\n📊 Using {num_heads} attention heads")
print("\n💡 Real-world analogy:")
print("   Head 1 might learn: subject-verb relationships")
print("   Head 2 might learn: adjective-noun relationships")
print("   Head 3 might learn: long-range dependencies")
print("   etc.")

print(f"\nWith {num_heads} heads and d_model={d_model}:")
print(f"   Each head processes d_model/{num_heads} = {d_model//num_heads} dimensions")

# Simulate multi-head attention
print("\nHead 1 attention weights:")
head1_weights = softmax(np.random.randn(len(words), len(words)))
print_matrix(head1_weights, words, words, "")

print("\nHead 2 attention weights (different pattern!):")
head2_weights = softmax(np.random.randn(len(words), len(words)))
print_matrix(head2_weights, words, words, "")

print("\n💡 Key Insight:")
print("   Different heads learn to focus on different aspects!")
print("   This makes the model much more powerful.")


# ============================================================================
# STEP 5: Feed-Forward Network
# ============================================================================

print_section("STEP 5: Feed-Forward Network")

print("🎯 Purpose: Add non-linear transformations")
print("   Attention captures relationships, FFN adds complexity")

print("\n📊 Architecture: Linear → ReLU → Linear")
print("   Common pattern: Expand then compress")
print(f"   Example: {d_model} → {d_model*4} → {d_model}")

# Simple feed-forward
d_ff = d_model * 4
W1 = np.random.randn(d_model, d_ff) * 0.1
W2 = np.random.randn(d_ff, d_model) * 0.1

# Apply to first word
x_input = output[0:1, :]  # First word's embedding
print(f"\nInput shape: {x_input.shape}")

hidden = np.maximum(0, x_input @ W1)  # ReLU activation
print(f"After first layer (ReLU): {hidden.shape}")

ff_output = hidden @ W2
print(f"After second layer: {ff_output.shape}")

print("\n💡 Key Insight:")
print("   FFN is applied to each position independently")
print("   Adds capacity for complex transformations")


# ============================================================================
# STEP 6: Complete Transformer Block
# ============================================================================

print_section("STEP 6: Putting It All Together - Transformer Block")

print("🏗️  A complete transformer block consists of:")
print("\n   1. Multi-Head Attention")
print("      ↓")
print("   2. Add & Normalize (Residual Connection)")
print("      ↓")
print("   3. Feed-Forward Network")
print("      ↓")
print("   4. Add & Normalize (Residual Connection)")

print("\n🔄 Residual Connections:")
print("   Instead of: output = Layer(input)")
print("   We do: output = input + Layer(input)")
print("\n   Benefits:")
print("   ✅ Helps training deep networks")
print("   ✅ Prevents vanishing gradients")
print("   ✅ Allows information to flow directly")

print("\n📊 Flow through one block:")
x_block = X.copy()
print(f"   Input:  shape {x_block.shape}")

# Multi-head attention
attn_output = attention_weights @ V
print(f"   After attention: shape {attn_output.shape}")

# Residual + Norm
x_block = x_block + attn_output  # Residual
mean = np.mean(x_block, axis=-1, keepdims=True)
std = np.std(x_block, axis=-1, keepdims=True)
x_block = (x_block - mean) / (std + 1e-6)  # Normalize
print(f"   After Add & Norm: shape {x_block.shape}")

# Feed-forward
ff_out = np.maximum(0, x_block @ W1) @ W2
print(f"   After FFN: shape {ff_out.shape}")

# Residual + Norm
x_block = x_block + ff_out
x_block = (x_block - mean) / (std + 1e-6)
print(f"   Final output: shape {x_block.shape}")

print("\n✅ One transformer block complete!")


# ============================================================================
# STEP 7: Stacking Layers
# ============================================================================

print_section("STEP 7: Stacking Multiple Layers")

print("🎯 Real LLMs stack many transformer blocks!")
print("\nExamples:")
print("   • GPT-3: 96 layers")
print("   • GPT-4: ~120 layers (estimated)")
print("   • Claude: Many layers (exact number not public)")
print("   • BERT: 12-24 layers")

print("\n📊 Why stack layers?")
print("   Layer 1: Learns simple patterns (adjacent words)")
print("   Layer 2-3: Learns syntax (grammar structures)")
print("   Layer 4-6: Learns semantics (meaning)")
print("   Layer 7+: Learns complex reasoning")

print("\n💡 Think of it like this:")
print("   • Early layers: 'I see individual words'")
print("   • Middle layers: 'I understand sentences'")
print("   • Deep layers: 'I grasp complex ideas and context'")

num_layers = 3
print(f"\nSimulating {num_layers} stacked layers:")
x_stacked = X.copy()
for layer in range(num_layers):
    print(f"   Layer {layer + 1}: Processing... → shape {x_stacked.shape}")
    # Simulate layer processing
    x_stacked = x_stacked + np.random.randn(*x_stacked.shape) * 0.01

print(f"\n   Final output shape: {x_stacked.shape}")


# ============================================================================
# STEP 8: From Embeddings to Predictions
# ============================================================================

print_section("STEP 8: Generating Predictions")

print("🎯 Final step: Convert transformer output back to words")
print("\n📊 Process:")
print("   1. Transformer output: embeddings")
print("   2. Project to vocabulary size")
print("   3. Apply softmax to get probabilities")
print("   4. Sample or pick most likely next word")

vocab_size = 10  # Simplified vocabulary
vocab = ["The", "cat", "sat", "on", "mat", "dog", "ran", ".", "ate", "slept"]

print(f"\nVocabulary size: {vocab_size}")
print(f"Words: {vocab}")

# Project to vocabulary (simplified)
W_vocab = np.random.randn(d_model, vocab_size) * 0.1
last_word_embedding = x_stacked[-1:, :]  # Last word's embedding

logits = last_word_embedding @ W_vocab
probs = softmax(logits)

print("\n🎲 Probability distribution for next word:")
sorted_indices = np.argsort(probs[0])[::-1]
for idx in sorted_indices[:5]:  # Top 5
    print(f"   '{vocab[idx]}': {probs[0, idx]:.1%}")

predicted_word = vocab[sorted_indices[0]]
print(f"\n✅ Most likely next word: '{predicted_word}'")

print("\n💡 This is how LLMs generate text!")
print("   They predict one word at a time, then add it to context")
print("   and predict the next word, and so on...")


# ============================================================================
# FINAL SUMMARY
# ============================================================================

print_section("🎓 SUMMARY: How Transformers Work")

print("""
The Complete Pipeline:
═══════════════════════════════════════════════════════════════

1️⃣  TOKENIZATION
   "The cat sat" → [Token IDs: 10, 45, 89]

2️⃣  EMBEDDING
   Token IDs → Dense vectors (embeddings)
   Example: "cat" → [0.5, 0.8, 0.2, 0.3]

3️⃣  POSITIONAL ENCODING
   Add position information so model knows word order
   Final embedding = word embedding + position encoding

4️⃣  TRANSFORMER BLOCKS (Stacked N times)
   For each block:
   
   a) Multi-Head Self-Attention
      • Create Q, K, V matrices
      • Calculate attention scores
      • Let each word attend to all words
      • Multiple heads learn different relationships
   
   b) Add & Normalize
      • Residual connection: output = input + attention_output
      • Layer normalization for stability
   
   c) Feed-Forward Network
      • Non-linear transformations
      • Applied to each position independently
   
   d) Add & Normalize
      • Another residual connection
      • Another normalization

5️⃣  OUTPUT PROJECTION
   Transform embeddings back to vocabulary space
   Get probability distribution over all possible next words

6️⃣  SAMPLING/SELECTION
   Pick the next word based on probabilities
   Add to context and repeat for generation


Key Innovations that Make Transformers Powerful:
═══════════════════════════════════════════════════════════════

✅ Self-Attention
   Words can look at ALL other words simultaneously
   No sequential processing needed (can be parallelized)

✅ Multi-Head Attention
   Multiple attention mechanisms learn different relationships
   Like having multiple experts analyze the text

✅ Positional Encoding
   Maintains word order information despite parallel processing

✅ Residual Connections
   Enables training very deep networks (100+ layers)
   Prevents vanishing gradients

✅ Layer Normalization
   Stabilizes training
   Makes deep networks practical


Why Transformers Revolutionized AI:
═══════════════════════════════════════════════════════════════

🚀 Scalability
   Can be trained on massive datasets efficiently
   Parallelizable (unlike RNNs which are sequential)

🚀 Long-Range Dependencies
   Can capture relationships across long distances
   Not limited by sequential processing

🚀 Transfer Learning
   Pre-train once, fine-tune for many tasks
   Enables models like GPT, BERT, Claude

🚀 Emergent Capabilities
   Large transformers show unexpected abilities:
   • Few-shot learning
   • Reasoning
   • Multi-task performance


Real-World Scale:
═══════════════════════════════════════════════════════════════

This tutorial:
• 3 words
• 4-dimensional embeddings
• 2-3 layers

Real LLMs:
• Thousands of tokens
• 4096-12288 dimensional embeddings
• 96-120+ layers
• 175B - 1T+ parameters
• Trained on trillions of words
""")

print("="*70)
print("🎉 Congratulations! You now understand transformers!")
print("="*70)

print("""
Next Steps:
───────────────────────────────────────────────────────────────
1. Run the full transformer_explained.py for more details
2. Experiment with different hyperparameters
3. Study attention visualizations
4. Read papers: "Attention is All You Need" (original paper)
5. Try implementing a small transformer yourself!

Remember: The transformer architecture is the foundation of:
• GPT (OpenAI)
• Claude (Anthropic)
• BERT (Google)
• LLaMA (Meta)
• And most modern LLMs!
""")

print("\n✨ Happy learning! ✨\n")
