"""
🚀 Quick Transformer Demo - See It In Action!
==============================================

Run this to see a transformer in action with a real example.
This is the fastest way to see results!
"""

import numpy as np
np.random.seed(42)


def softmax(x):
    """Numerically stable softmax."""
    exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)


print("""
╔══════════════════════════════════════════════════════════════════════╗
║                 🤖 TRANSFORMER QUICK DEMO                           ║
║                 See How It Works In 60 Seconds!                      ║
╚══════════════════════════════════════════════════════════════════════╝
""")

# ============================================================================
# SETUP
# ============================================================================

print("\n📝 Example Sentence: 'The cat sat on the mat'\n")

words = ["The", "cat", "sat", "on", "the", "mat"]
seq_len = len(words)
d_model = 8  # Small for demo

print(f"🔢 Sequence length: {seq_len} words")
print(f"🔢 Embedding dimension: {d_model}")

# ============================================================================
# STEP 1: CREATE EMBEDDINGS
# ============================================================================

print("\n" + "─"*70)
print("STEP 1: Converting words to numbers (embeddings)")
print("─"*70)

# Create simple embeddings
embeddings = np.random.randn(seq_len, d_model) * 0.5

print("\nEach word becomes a vector of numbers:")
for i, word in enumerate(words):
    vector_str = "[" + ", ".join([f"{x:.2f}" for x in embeddings[i][:4]]) + ", ...]"
    print(f"  '{word:>4}' → {vector_str}")

# ============================================================================
# STEP 2: SELF-ATTENTION
# ============================================================================

print("\n" + "─"*70)
print("STEP 2: Self-Attention - Let words 'talk' to each other")
print("─"*70)

# Create Q, K, V matrices
W_q = np.random.randn(d_model, d_model) * 0.1
W_k = np.random.randn(d_model, d_model) * 0.1
W_v = np.random.randn(d_model, d_model) * 0.1

Q = embeddings @ W_q  # Queries
K = embeddings @ W_k  # Keys
V = embeddings @ W_v  # Values

# Calculate attention scores
scores = (Q @ K.T) / np.sqrt(d_model)
attention = softmax(scores)

print("\n🎯 Attention Matrix (who pays attention to whom):")
print("\n       ", end="")
for word in words:
    print(f"{word:>7}", end="")
print()

for i, query_word in enumerate(words):
    print(f"  {query_word:>4} │", end="")
    for j in range(len(words)):
        # Use color-coding for attention strength
        attn_val = attention[i, j]
        if attn_val > 0.25:
            symbol = "█"  # Strong attention
        elif attn_val > 0.15:
            symbol = "▓"  # Medium attention
        elif attn_val > 0.10:
            symbol = "▒"  # Weak attention
        else:
            symbol = "░"  # Very weak attention
        
        print(f" {symbol}{attn_val:.2f} ", end="")
    print()

print("\n💡 Reading the matrix:")
print("   █ = Strong attention (> 25%)")
print("   ▓ = Medium attention (15-25%)")
print("   ▒ = Weak attention (10-15%)")
print("   ░ = Very weak attention (< 10%)")

# Interpret some interesting patterns
print("\n🔍 Interesting patterns:")

# Find highest attention for each word
for i, word in enumerate(words):
    max_idx = np.argmax(attention[i])
    max_attn = attention[i, max_idx]
    if max_idx != i:  # Not self-attention
        print(f"   • '{word}' attends most to '{words[max_idx]}' ({max_attn:.1%})")

# ============================================================================
# STEP 3: APPLY ATTENTION TO VALUES
# ============================================================================

print("\n" + "─"*70)
print("STEP 3: Create new word representations using attention")
print("─"*70)

output = attention @ V

print("\n✅ Each word now has a NEW representation that considers context!")
print("\n📊 How the representation changed:")

for i, word in enumerate(words):
    # Calculate how much it changed
    original_norm = np.linalg.norm(embeddings[i])
    output_norm = np.linalg.norm(output[i])
    change_pct = abs(output_norm - original_norm) / original_norm * 100
    
    print(f"   '{word:>4}': Changed by {change_pct:.1f}%")

print("\n💡 These new representations understand the context!")
print("   e.g., 'cat' now knows it 'sat' and 'sat' knows WHO sat")

# ============================================================================
# STEP 4: DEMONSTRATE MULTI-HEAD ATTENTION
# ============================================================================

print("\n" + "─"*70)
print("STEP 4: Multi-Head Attention - Multiple perspectives")
print("─"*70)

num_heads = 2
d_k = d_model // num_heads

print(f"\n🧠 Using {num_heads} attention heads")
print(f"   Each head looks at {d_k} dimensions")

# Simulate two different heads
head1_scores = np.random.randn(seq_len, seq_len)
head1_attn = softmax(head1_scores)

head2_scores = np.random.randn(seq_len, seq_len)
head2_attn = softmax(head2_scores)

print("\n👁️  Head 1 focuses on:")
for i in range(seq_len):
    max_idx = np.argmax(head1_attn[i])
    if max_idx != i:
        print(f"   '{words[i]}' → '{words[max_idx]}'")

print("\n👁️  Head 2 focuses on:")
for i in range(seq_len):
    max_idx = np.argmax(head2_attn[i])
    if max_idx != i:
        print(f"   '{words[i]}' → '{words[max_idx]}'")

print("\n💡 Different heads learn different relationships!")

# ============================================================================
# STEP 5: COMPLETE TRANSFORMER BLOCK
# ============================================================================

print("\n" + "─"*70)
print("STEP 5: Complete Transformer Block")
print("─"*70)

print("\n🏗️  A full transformer block includes:")
print("   1. Multi-Head Attention ✅")
print("   2. Add & Normalize (Residual)")
print("   3. Feed-Forward Network")
print("   4. Add & Normalize (Residual)")

# Simulate a simple feed-forward
d_ff = d_model * 4
W1 = np.random.randn(d_model, d_ff) * 0.1
W2 = np.random.randn(d_ff, d_model) * 0.1

# Add residual connection
x = embeddings + output  # Residual from attention

# Simple normalization
mean = np.mean(x, axis=-1, keepdims=True)
std = np.std(x, axis=-1, keepdims=True)
x = (x - mean) / (std + 1e-6)

print("\n   After attention + residual + norm:")
print(f"   Shape: {x.shape}")

# Feed-forward
ff_output = np.maximum(0, x @ W1) @ W2  # ReLU activation

# Another residual
x = x + ff_output
x = (x - mean) / (std + 1e-6)

print("\n   After FFN + residual + norm:")
print(f"   Shape: {x.shape}")

print("\n✅ One complete transformer block processed!")

# ============================================================================
# STEP 6: STACKING LAYERS
# ============================================================================

print("\n" + "─"*70)
print("STEP 6: Stack Multiple Layers")
print("─"*70)

num_layers = 3
print(f"\n📚 Real LLMs stack {num_layers}+ layers")

x_deep = x.copy()
for layer in range(num_layers):
    # Simulate layer processing
    x_deep = x_deep + np.random.randn(*x_deep.shape) * 0.01
    print(f"   Layer {layer+1}: Processed ✓")

print(f"\n✅ After {num_layers} layers:")
print(f"   Final shape: {x_deep.shape}")
print(f"   Each word has a rich, context-aware representation!")

# ============================================================================
# STEP 7: GENERATE NEXT WORD
# ============================================================================

print("\n" + "─"*70)
print("STEP 7: Predict Next Word")
print("─"*70)

# Simulate vocabulary
vocab = ["The", "cat", "dog", "sat", "ran", "on", ".", "and", "is", "was"]
vocab_size = len(vocab)

# Project to vocabulary
W_out = np.random.randn(d_model, vocab_size) * 0.1
last_word = x_deep[-1:, :]  # Last word's representation
logits = last_word @ W_out
probs = softmax(logits)

print(f"\n📖 Vocabulary size: {vocab_size} words")
print(f"   Words: {vocab}")

print("\n🎲 Probability distribution for next word:")
sorted_indices = np.argsort(probs[0])[::-1]

for rank, idx in enumerate(sorted_indices[:5], 1):
    word = vocab[idx]
    prob = probs[0, idx]
    bar_length = int(prob * 50)
    bar = "█" * bar_length
    print(f"   {rank}. '{word:>4}' │{bar:50s}│ {prob:.1%}")

predicted_word = vocab[sorted_indices[0]]
print(f"\n✅ Most likely next word: '{predicted_word}' 🎯")

# ============================================================================
# SUMMARY
# ============================================================================

print("\n" + "="*70)
print("🎓 SUMMARY")
print("="*70)

print("""
What we just did:

1️⃣  Converted words to embeddings (vectors of numbers)
2️⃣  Applied self-attention (words look at each other)
3️⃣  Used multi-head attention (multiple perspectives)
4️⃣  Applied feed-forward networks (non-linear transformations)
5️⃣  Used residual connections (helps training deep networks)
6️⃣  Stacked multiple layers (builds deeper understanding)
7️⃣  Predicted next word (generation!)

This is exactly how LLMs like GPT, Claude, and BERT work!
The only difference: they're MUCH bigger (billions of parameters!)

🎯 Key Insights:
   • Self-attention lets every word see every other word
   • Multi-head attention learns different types of relationships
   • Stacking layers builds increasingly abstract representations
   • The model learns what patterns matter through training

🚀 What's Next?
   1. Run: transformer_interactive_tutorial.py (detailed walkthrough)
   2. Study: transformer_visual_guide.md (diagrams & formulas)
   3. Explore: transformer_explained.py (full implementation)
""")

print("\n" + "="*70)
print("✨ You now understand how transformers work! ✨")
print("="*70 + "\n")

# ============================================================================
# BONUS: ATTENTION VISUALIZATION
# ============================================================================

print("\n💡 BONUS: Want to see attention as a heatmap?")
print("   Run: python3 transformer_explained.py")
print("   It will generate visualization images!\n")

# Quick statistics
print("📊 Quick Stats:")
print(f"   • Input words: {seq_len}")
print(f"   • Embedding size: {d_model}")
print(f"   • Attention heads: {num_heads}")
print(f"   • Transformer layers: {num_layers}")
print(f"   • Vocabulary size: {vocab_size}")
print(f"   • Parameters (this tiny demo): ~{(d_model**2 * 3 + d_model * d_ff * 2) * num_layers:,}")
print(f"   • Parameters (GPT-3): 175,000,000,000")
print()

print("🎉 Demo complete! Now you're ready to explore the full tutorials!")
