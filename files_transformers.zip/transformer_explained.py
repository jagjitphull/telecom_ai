"""
🤖 Understanding Transformers in LLMs - Educational Implementation
==================================================================

This code demonstrates the core components of a Transformer architecture
used in Large Language Models (LLMs) like GPT, BERT, and Claude.

Key Components Covered:
1. Self-Attention Mechanism
2. Multi-Head Attention
3. Positional Encoding
4. Feed-Forward Networks
5. Layer Normalization
6. Complete Transformer Block
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Optional

# Set random seed for reproducibility
np.random.seed(42)


# ============================================================================
# 1. POSITIONAL ENCODING
# ============================================================================

class PositionalEncoding:
    """
    Adds positional information to word embeddings.
    
    WHY? Transformers process all words in parallel (unlike RNNs that are sequential).
    So we need to tell the model WHERE each word is in the sequence.
    
    Example: "I love cats" vs "Cats love I" - same words, different meanings!
    """
    
    def __init__(self, d_model: int, max_len: int = 5000):
        """
        Args:
            d_model: Dimension of embeddings (e.g., 512)
            max_len: Maximum sequence length
        """
        self.d_model = d_model
        
        # Create positional encoding matrix
        position = np.arange(max_len)[:, np.newaxis]  # Shape: (max_len, 1)
        div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))
        
        pe = np.zeros((max_len, d_model))
        pe[:, 0::2] = np.sin(position * div_term)  # Even indices
        pe[:, 1::2] = np.cos(position * div_term)  # Odd indices
        
        self.pe = pe
    
    def encode(self, x: np.ndarray) -> np.ndarray:
        """
        Add positional encoding to input embeddings.
        
        Args:
            x: Input embeddings, shape (seq_len, d_model)
        Returns:
            Embeddings with position information added
        """
        seq_len = x.shape[0]
        return x + self.pe[:seq_len]


# ============================================================================
# 2. SELF-ATTENTION MECHANISM (The Heart of Transformers!)
# ============================================================================

class SelfAttention:
    """
    Self-Attention: How words "pay attention" to each other.
    
    INTUITION:
    - In "The cat sat on the mat", the word "sat" should pay more attention 
      to "cat" (who sat?) than to "the" (not very informative).
    
    HOW IT WORKS:
    1. Query (Q): "What am I looking for?"
    2. Key (K): "What do I contain?"
    3. Value (V): "What do I actually represent?"
    
    Attention Score = How well Query matches Key
    Output = Weighted sum of Values based on attention scores
    """
    
    def __init__(self, d_model: int):
        """
        Args:
            d_model: Dimension of embeddings
        """
        self.d_model = d_model
        
        # Initialize weight matrices (normally these are learned during training)
        self.W_q = np.random.randn(d_model, d_model) * 0.01  # Query weights
        self.W_k = np.random.randn(d_model, d_model) * 0.01  # Key weights
        self.W_v = np.random.randn(d_model, d_model) * 0.01  # Value weights
    
    def forward(self, x: np.ndarray, mask: Optional[np.ndarray] = None) -> tuple:
        """
        Compute self-attention.
        
        Args:
            x: Input embeddings, shape (seq_len, d_model)
            mask: Optional attention mask (for causal/masked attention)
        
        Returns:
            output: Attention output
            attention_weights: Attention scores (for visualization)
        """
        # Step 1: Create Query, Key, Value matrices
        Q = x @ self.W_q  # (seq_len, d_model)
        K = x @ self.W_k  # (seq_len, d_model)
        V = x @ self.W_v  # (seq_len, d_model)
        
        # Step 2: Calculate attention scores
        # Scores = Q @ K^T / sqrt(d_model)
        # Division by sqrt(d_model) prevents scores from getting too large
        scores = (Q @ K.T) / np.sqrt(self.d_model)  # (seq_len, seq_len)
        
        # Step 3: Apply mask (if provided)
        # Used for causal attention: prevent looking at future words
        if mask is not None:
            scores = scores + mask
        
        # Step 4: Apply softmax to get attention weights
        # Softmax converts scores to probabilities (sum to 1)
        attention_weights = self.softmax(scores)
        
        # Step 5: Apply attention weights to values
        output = attention_weights @ V  # (seq_len, d_model)
        
        return output, attention_weights
    
    @staticmethod
    def softmax(x: np.ndarray) -> np.ndarray:
        """Numerically stable softmax."""
        exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)


# ============================================================================
# 3. MULTI-HEAD ATTENTION
# ============================================================================

class MultiHeadAttention:
    """
    Multi-Head Attention: Run multiple attention mechanisms in parallel.
    
    WHY MULTIPLE HEADS?
    - Different heads can learn different types of relationships:
      * Head 1: Subject-verb relationships
      * Head 2: Noun-adjective relationships
      * Head 3: Long-range dependencies
      * etc.
    
    Like having multiple experts looking at the same sentence from different angles!
    """
    
    def __init__(self, d_model: int, num_heads: int):
        """
        Args:
            d_model: Dimension of embeddings (must be divisible by num_heads)
            num_heads: Number of attention heads
        """
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads  # Dimension per head
        
        # Create separate attention heads
        self.heads = [SelfAttention(self.d_k) for _ in range(num_heads)]
        
        # Output projection
        self.W_o = np.random.randn(d_model, d_model) * 0.01
    
    def forward(self, x: np.ndarray, mask: Optional[np.ndarray] = None) -> tuple:
        """
        Compute multi-head attention.
        
        Args:
            x: Input embeddings, shape (seq_len, d_model)
            mask: Optional attention mask
        
        Returns:
            output: Multi-head attention output
            all_attention_weights: List of attention weights from each head
        """
        seq_len = x.shape[0]
        all_attention_weights = []
        
        # Split input into multiple heads
        # Each head processes a portion of the embedding dimension
        head_outputs = []
        
        for i, head in enumerate(self.heads):
            # Extract this head's portion of the embeddings
            start_idx = i * self.d_k
            end_idx = (i + 1) * self.d_k
            x_head = x[:, start_idx:end_idx]
            
            # Apply attention for this head
            output, attn_weights = head.forward(x_head, mask)
            head_outputs.append(output)
            all_attention_weights.append(attn_weights)
        
        # Concatenate all head outputs
        concat_output = np.concatenate(head_outputs, axis=-1)
        
        # Final linear projection
        output = concat_output @ self.W_o
        
        return output, all_attention_weights


# ============================================================================
# 4. FEED-FORWARD NETWORK
# ============================================================================

class FeedForward:
    """
    Position-wise Feed-Forward Network.
    
    WHY?
    - Attention captures relationships between words
    - Feed-forward adds non-linear transformations
    - Helps the model learn complex patterns
    
    Architecture: Linear -> ReLU -> Linear
    Common practice: Expand then compress (e.g., 512 -> 2048 -> 512)
    """
    
    def __init__(self, d_model: int, d_ff: int):
        """
        Args:
            d_model: Input/output dimension
            d_ff: Hidden layer dimension (usually 4 * d_model)
        """
        self.W1 = np.random.randn(d_model, d_ff) * 0.01
        self.b1 = np.zeros(d_ff)
        self.W2 = np.random.randn(d_ff, d_model) * 0.01
        self.b2 = np.zeros(d_model)
    
    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Apply feed-forward network.
        
        Args:
            x: Input, shape (seq_len, d_model)
        Returns:
            Output, same shape as input
        """
        # First layer with ReLU activation
        hidden = np.maximum(0, x @ self.W1 + self.b1)  # ReLU
        
        # Second layer (no activation)
        output = hidden @ self.W2 + self.b2
        
        return output


# ============================================================================
# 5. LAYER NORMALIZATION
# ============================================================================

class LayerNorm:
    """
    Layer Normalization: Stabilizes training.
    
    WHY?
    - Prevents values from getting too large or too small
    - Makes training faster and more stable
    - Normalizes across features for each sample
    """
    
    def __init__(self, d_model: int, eps: float = 1e-6):
        """
        Args:
            d_model: Dimension to normalize
            eps: Small constant to prevent division by zero
        """
        self.eps = eps
        self.gamma = np.ones(d_model)  # Learnable scale
        self.beta = np.zeros(d_model)  # Learnable shift
    
    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Apply layer normalization.
        
        Args:
            x: Input, shape (seq_len, d_model)
        Returns:
            Normalized output
        """
        mean = np.mean(x, axis=-1, keepdims=True)
        std = np.std(x, axis=-1, keepdims=True)
        
        # Normalize
        x_norm = (x - mean) / (std + self.eps)
        
        # Scale and shift
        return self.gamma * x_norm + self.beta


# ============================================================================
# 6. TRANSFORMER BLOCK (Putting It All Together!)
# ============================================================================

class TransformerBlock:
    """
    Complete Transformer Block.
    
    ARCHITECTURE:
    1. Multi-Head Attention + Residual Connection + Layer Norm
    2. Feed-Forward Network + Residual Connection + Layer Norm
    
    RESIDUAL CONNECTIONS (x + Layer(x)):
    - Help gradients flow during training
    - Prevent vanishing gradient problem
    - Allow building very deep networks
    """
    
    def __init__(self, d_model: int, num_heads: int, d_ff: int, dropout: float = 0.1):
        """
        Args:
            d_model: Embedding dimension
            num_heads: Number of attention heads
            d_ff: Feed-forward hidden dimension
            dropout: Dropout rate (not implemented in this simple version)
        """
        self.attention = MultiHeadAttention(d_model, num_heads)
        self.feed_forward = FeedForward(d_model, d_ff)
        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)
    
    def forward(self, x: np.ndarray, mask: Optional[np.ndarray] = None) -> tuple:
        """
        Forward pass through transformer block.
        
        Args:
            x: Input embeddings, shape (seq_len, d_model)
            mask: Optional attention mask
        
        Returns:
            output: Transformed embeddings
            attention_weights: Attention weights for visualization
        """
        # 1. Multi-Head Attention with residual connection and normalization
        attn_output, attention_weights = self.attention.forward(x, mask)
        x = self.norm1.forward(x + attn_output)  # Residual + Norm
        
        # 2. Feed-Forward with residual connection and normalization
        ff_output = self.feed_forward.forward(x)
        x = self.norm2.forward(x + ff_output)  # Residual + Norm
        
        return x, attention_weights


# ============================================================================
# 7. SIMPLE TRANSFORMER MODEL
# ============================================================================

class SimpleTransformer:
    """
    Simplified Transformer Model.
    
    This demonstrates the core architecture used in LLMs:
    - Input Embedding + Positional Encoding
    - Stack of Transformer Blocks
    - Output Projection
    """
    
    def __init__(self, vocab_size: int, d_model: int, num_heads: int, 
                 num_layers: int, d_ff: int, max_seq_len: int = 512):
        """
        Args:
            vocab_size: Size of vocabulary
            d_model: Embedding dimension
            num_heads: Number of attention heads
            num_layers: Number of transformer blocks
            d_ff: Feed-forward hidden dimension
            max_seq_len: Maximum sequence length
        """
        # Input embedding (converts token IDs to embeddings)
        self.embedding = np.random.randn(vocab_size, d_model) * 0.01
        
        # Positional encoding
        self.pos_encoding = PositionalEncoding(d_model, max_seq_len)
        
        # Stack of transformer blocks
        self.blocks = [
            TransformerBlock(d_model, num_heads, d_ff) 
            for _ in range(num_layers)
        ]
        
        # Output projection (back to vocabulary)
        self.output_projection = np.random.randn(d_model, vocab_size) * 0.01
    
    def forward(self, input_ids: np.ndarray, mask: Optional[np.ndarray] = None) -> tuple:
        """
        Forward pass through the transformer.
        
        Args:
            input_ids: Token IDs, shape (seq_len,)
            mask: Optional attention mask
        
        Returns:
            logits: Output logits, shape (seq_len, vocab_size)
            all_attention_weights: Attention weights from all layers
        """
        # 1. Convert token IDs to embeddings
        x = self.embedding[input_ids]  # (seq_len, d_model)
        
        # 2. Add positional encoding
        x = self.pos_encoding.encode(x)
        
        # 3. Pass through transformer blocks
        all_attention_weights = []
        for block in self.blocks:
            x, attn_weights = block.forward(x, mask)
            all_attention_weights.append(attn_weights)
        
        # 4. Project to vocabulary
        logits = x @ self.output_projection  # (seq_len, vocab_size)
        
        return logits, all_attention_weights


# ============================================================================
# 8. VISUALIZATION FUNCTIONS
# ============================================================================

def visualize_attention(attention_weights: np.ndarray, tokens: list, 
                        title: str = "Attention Weights"):
    """
    Visualize attention weights as a heatmap.
    
    Args:
        attention_weights: Attention matrix, shape (seq_len, seq_len)
        tokens: List of token strings
        title: Plot title
    """
    plt.figure(figsize=(10, 8))
    plt.imshow(attention_weights, cmap='viridis', aspect='auto')
    plt.colorbar(label='Attention Weight')
    plt.xticks(range(len(tokens)), tokens, rotation=45, ha='right')
    plt.yticks(range(len(tokens)), tokens)
    plt.xlabel('Key Position')
    plt.ylabel('Query Position')
    plt.title(title)
    plt.tight_layout()
    return plt


def visualize_positional_encoding(pe: np.ndarray, max_display: int = 50):
    """
    Visualize positional encoding patterns.
    
    Args:
        pe: Positional encoding matrix, shape (max_len, d_model)
        max_display: Maximum positions to display
    """
    plt.figure(figsize=(12, 6))
    plt.imshow(pe[:max_display].T, cmap='RdBu', aspect='auto')
    plt.colorbar(label='Encoding Value')
    plt.xlabel('Position in Sequence')
    plt.ylabel('Embedding Dimension')
    plt.title('Positional Encoding Patterns')
    plt.tight_layout()
    return plt


# ============================================================================
# 9. DEMONSTRATION & EXAMPLES
# ============================================================================

def demonstrate_self_attention():
    """
    Demonstrate self-attention with a simple example.
    """
    print("\n" + "="*70)
    print("🔍 DEMONSTRATION 1: SELF-ATTENTION MECHANISM")
    print("="*70)
    
    # Create simple example: 3 words with 8-dimensional embeddings
    sentence = ["The", "cat", "sat"]
    d_model = 8
    seq_len = len(sentence)
    
    # Random embeddings (in real LLMs, these are learned)
    x = np.random.randn(seq_len, d_model)
    
    print(f"\n📝 Input: {' '.join(sentence)}")
    print(f"   Sequence length: {seq_len}")
    print(f"   Embedding dimension: {d_model}")
    
    # Apply self-attention
    attention = SelfAttention(d_model)
    output, attention_weights = attention.forward(x)
    
    print(f"\n✅ Output shape: {output.shape}")
    print(f"\n🎯 Attention Weights (who pays attention to whom):")
    print("   Rows = Query words, Columns = Key words")
    print()
    
    # Print attention matrix
    header = "        " + "  ".join([f"{word:>8}" for word in sentence])
    print(header)
    print("   " + "-" * len(header))
    
    for i, query_word in enumerate(sentence):
        weights_str = "  ".join([f"{w:8.3f}" for w in attention_weights[i]])
        print(f"   {query_word:>4} | {weights_str}")
    
    print("\n💡 Interpretation:")
    print("   - Each row sums to 1.0 (it's a probability distribution)")
    print("   - Higher values = stronger attention")
    print("   - 'cat' might attend strongly to 'sat' (subject-verb relationship)")
    
    return attention_weights, sentence


def demonstrate_transformer_block():
    """
    Demonstrate a complete transformer block.
    """
    print("\n" + "="*70)
    print("🏗️  DEMONSTRATION 2: COMPLETE TRANSFORMER BLOCK")
    print("="*70)
    
    # Parameters
    seq_len = 5
    d_model = 64
    num_heads = 4
    d_ff = 256
    
    print(f"\n⚙️  Configuration:")
    print(f"   Sequence length: {seq_len} tokens")
    print(f"   Embedding dimension: {d_model}")
    print(f"   Number of attention heads: {num_heads}")
    print(f"   Feed-forward dimension: {d_ff}")
    
    # Create random input
    x = np.random.randn(seq_len, d_model)
    
    # Create transformer block
    block = TransformerBlock(d_model, num_heads, d_ff)
    
    print(f"\n📥 Input shape: {x.shape}")
    
    # Forward pass
    output, attention_weights = block.forward(x)
    
    print(f"📤 Output shape: {output.shape}")
    print(f"\n✅ Successfully processed through:")
    print(f"   1. Multi-Head Attention ({num_heads} heads)")
    print(f"   2. Layer Normalization")
    print(f"   3. Feed-Forward Network")
    print(f"   4. Layer Normalization")
    
    print(f"\n🎯 Number of attention heads: {len(attention_weights)}")
    print(f"   Each head learns different relationships!")
    
    return output, attention_weights


def demonstrate_full_transformer():
    """
    Demonstrate a complete (simplified) transformer model.
    """
    print("\n" + "="*70)
    print("🤖 DEMONSTRATION 3: FULL TRANSFORMER MODEL")
    print("="*70)
    
    # Parameters
    vocab_size = 1000  # Size of vocabulary
    d_model = 128      # Embedding dimension
    num_heads = 8      # Number of attention heads
    num_layers = 3     # Number of transformer blocks
    d_ff = 512         # Feed-forward dimension
    
    print(f"\n⚙️  Model Configuration:")
    print(f"   Vocabulary size: {vocab_size:,}")
    print(f"   Embedding dimension: {d_model}")
    print(f"   Attention heads: {num_heads}")
    print(f"   Transformer layers: {num_layers}")
    print(f"   Feed-forward dimension: {d_ff}")
    
    # Create model
    model = SimpleTransformer(vocab_size, d_model, num_heads, num_layers, d_ff)
    
    # Example input: token IDs
    input_tokens = ["The", "quick", "brown", "fox"]
    input_ids = np.array([10, 45, 67, 89])  # Mock token IDs
    
    print(f"\n📝 Input: {' '.join(input_tokens)}")
    print(f"   Token IDs: {input_ids}")
    
    # Forward pass
    logits, all_attention_weights = model.forward(input_ids)
    
    print(f"\n✅ Model Output:")
    print(f"   Logits shape: {logits.shape}")
    print(f"   (Each position has probability distribution over {vocab_size} tokens)")
    
    print(f"\n🎯 Collected attention from {num_layers} layers")
    print(f"   Each layer has {num_heads} attention heads")
    print(f"   Total attention patterns: {num_layers * num_heads}")
    
    # Calculate model size (approximate)
    embedding_params = vocab_size * d_model
    attention_params = num_layers * (d_model * d_model * 4)  # Q, K, V, O
    ff_params = num_layers * (d_model * d_ff * 2)  # Two linear layers
    total_params = embedding_params + attention_params + ff_params
    
    print(f"\n📊 Model Size (approximate):")
    print(f"   Total parameters: {total_params:,}")
    print(f"   (~{total_params / 1_000_000:.2f}M parameters)")
    print(f"\n💡 Real LLMs like GPT-3 have 175 BILLION parameters!")
    
    return model, logits, all_attention_weights


def demonstrate_positional_encoding():
    """
    Demonstrate and visualize positional encoding.
    """
    print("\n" + "="*70)
    print("📍 DEMONSTRATION 4: POSITIONAL ENCODING")
    print("="*70)
    
    d_model = 128
    max_len = 100
    
    print(f"\n⚙️  Configuration:")
    print(f"   Embedding dimension: {d_model}")
    print(f"   Maximum sequence length: {max_len}")
    
    # Create positional encoding
    pos_enc = PositionalEncoding(d_model, max_len)
    
    print(f"\n✅ Created positional encoding matrix: {pos_enc.pe.shape}")
    
    # Example: encode a sequence
    seq_len = 5
    x = np.random.randn(seq_len, d_model)
    x_with_pos = pos_enc.encode(x)
    
    print(f"\n📝 Example:")
    print(f"   Input embeddings shape: {x.shape}")
    print(f"   After adding position: {x_with_pos.shape}")
    print(f"\n💡 Now the model knows the position of each word!")
    
    return pos_enc


def create_causal_mask(seq_len: int) -> np.ndarray:
    """
    Create causal mask for autoregressive generation.
    
    Prevents attending to future positions (used in GPT-style models).
    """
    mask = np.triu(np.ones((seq_len, seq_len)) * -1e9, k=1)
    return mask


# ============================================================================
# 10. MAIN EXECUTION
# ============================================================================

def main():
    """
    Run all demonstrations.
    """
    print("\n")
    print("="*70)
    print("🎓 UNDERSTANDING TRANSFORMERS IN LLMs")
    print("="*70)
    print("\nThis tutorial demonstrates the key components of transformer")
    print("architecture used in modern Large Language Models (LLMs).")
    
    # Demo 1: Self-Attention
    attention_weights, tokens = demonstrate_self_attention()
    
    # Demo 2: Transformer Block
    block_output, block_attention = demonstrate_transformer_block()
    
    # Demo 3: Full Transformer
    model, logits, all_attention = demonstrate_full_transformer()
    
    # Demo 4: Positional Encoding
    pos_enc = demonstrate_positional_encoding()
    
    # Summary
    print("\n" + "="*70)
    print("📚 SUMMARY: KEY CONCEPTS")
    print("="*70)
    print("""
🎯 1. SELF-ATTENTION
   - Allows each word to "look at" all other words
   - Learns which words are important for understanding each word
   - Core innovation that made transformers powerful

🎯 2. MULTI-HEAD ATTENTION
   - Multiple attention mechanisms in parallel
   - Each head can learn different types of relationships
   - Like having multiple experts analyze the text

🎯 3. POSITIONAL ENCODING
   - Adds position information to embeddings
   - Necessary because transformers process all words in parallel
   - Uses sine/cosine functions for smooth encoding

🎯 4. FEED-FORWARD NETWORKS
   - Adds non-linear transformations
   - Helps model learn complex patterns
   - Applied independently to each position

🎯 5. LAYER NORMALIZATION
   - Stabilizes training
   - Prevents values from exploding or vanishing
   - Makes deep networks trainable

🎯 6. RESIDUAL CONNECTIONS
   - Adds input directly to output (x + Layer(x))
   - Helps gradients flow during training
   - Enables very deep networks (100+ layers)

💡 HOW IT ALL WORKS TOGETHER:
   1. Convert words to embeddings
   2. Add positional information
   3. Pass through multiple transformer blocks
   4. Each block: Attention → FFN (with residual + norm)
   5. Final output: probability distribution over vocabulary

🚀 IN REAL LLMs (GPT, Claude, etc.):
   - 100+ transformer layers
   - Billions of parameters
   - Trained on massive text corpora
   - Can generate human-like text
   - Understand context over thousands of tokens
    """)
    
    print("="*70)
    print("✅ Tutorial Complete!")
    print("="*70)
    
    # Offer to create visualizations
    print("\n📊 Would you like to generate visualizations?")
    print("   Run with visualizations to see attention patterns!")
    
    return {
        'attention_weights': attention_weights,
        'tokens': tokens,
        'model': model,
        'pos_enc': pos_enc
    }


if __name__ == "__main__":
    # Run demonstrations
    results = main()
    
    # Optional: Create visualizations
    print("\n🎨 Creating visualizations...")
    
    try:
        # Visualize attention weights
        fig1 = visualize_attention(
            results['attention_weights'], 
            results['tokens'],
            "Self-Attention: How Words Attend to Each Other"
        )
        fig1.savefig('/mnt/user-data/outputs/attention_visualization.png', 
                     dpi=150, bbox_inches='tight')
        print("   ✅ Saved: attention_visualization.png")
        
        # Visualize positional encoding
        fig2 = visualize_positional_encoding(results['pos_enc'].pe)
        fig2.savefig('/mnt/user-data/outputs/positional_encoding.png',
                     dpi=150, bbox_inches='tight')
        print("   ✅ Saved: positional_encoding.png")
        
        print("\n📁 Check the outputs folder for visualization images!")
        
    except Exception as e:
        print(f"   ⚠️  Could not create visualizations: {e}")
        print("   (This is normal if matplotlib is not in display mode)")
    
    print("\n🎉 All done! You now understand how transformers work!")
