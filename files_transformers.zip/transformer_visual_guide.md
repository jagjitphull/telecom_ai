# 🤖 Transformer Architecture - Visual Reference Guide

## Table of Contents
1. [High-Level Architecture](#high-level-architecture)
2. [Self-Attention Mechanism](#self-attention-mechanism)
3. [Multi-Head Attention](#multi-head-attention)
4. [Complete Transformer Block](#complete-transformer-block)
5. [Full Model Architecture](#full-model-architecture)
6. [Key Formulas](#key-formulas)

---

## High-Level Architecture

```
INPUT TEXT: "The cat sat on the mat"
     ↓
┌─────────────────────────────────────┐
│   TOKENIZATION                       │
│   ["The", "cat", "sat", ...]        │
│   → [token_ids]                      │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   EMBEDDING LAYER                    │
│   token_ids → dense vectors          │
│   Shape: (seq_len, d_model)         │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   POSITIONAL ENCODING                │
│   Add position information           │
│   embedding + pos_encoding           │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   TRANSFORMER BLOCK 1                │
│   • Multi-Head Attention             │
│   • Feed-Forward Network             │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   TRANSFORMER BLOCK 2                │
│   • Multi-Head Attention             │
│   • Feed-Forward Network             │
└─────────────────────────────────────┘
     ↓
     ⋮  (Stack N layers)
     ↓
┌─────────────────────────────────────┐
│   TRANSFORMER BLOCK N                │
│   • Multi-Head Attention             │
│   • Feed-Forward Network             │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   OUTPUT PROJECTION                  │
│   Map to vocabulary                  │
│   Shape: (seq_len, vocab_size)      │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│   SOFTMAX                            │
│   Convert to probabilities           │
└─────────────────────────────────────┘
     ↓
OUTPUT: Next word probabilities
```

---

## Self-Attention Mechanism

### Conceptual View
```
For each word, calculate:
"How much should I pay attention to every other word?"

Example: "The cat sat"
                               Query: "sat"
                                    ↓
        ┌───────────────┬───────────────┬───────────────┐
        │      Key      │      Key      │      Key      │
        │     "The"     │     "cat"     │     "sat"     │
        └───────────────┴───────────────┴───────────────┘
              ↓               ↓               ↓
        Score: 0.1      Score: 0.8      Score: 0.1
              ↓               ↓               ↓
        ┌──────────────────────────────────────────┐
        │  Softmax: [0.15, 0.70, 0.15]            │
        │  "sat" attends mostly to "cat"!          │
        └──────────────────────────────────────────┘
```

### Mathematical Flow
```
Input: X (seq_len × d_model)
     ↓
┌────────────────────────────────────┐
│  Create Q, K, V Matrices           │
│                                    │
│  Q = X · W_q  (Query)              │
│  K = X · W_k  (Key)                │
│  V = X · W_v  (Value)              │
└────────────────────────────────────┘
     ↓
┌────────────────────────────────────┐
│  Calculate Attention Scores        │
│                                    │
│  Scores = (Q · K^T) / √d_k         │
│                                    │
│  Shape: (seq_len × seq_len)        │
└────────────────────────────────────┘
     ↓
┌────────────────────────────────────┐
│  Apply Softmax                     │
│                                    │
│  Attention = softmax(Scores)       │
│                                    │
│  Each row sums to 1.0              │
└────────────────────────────────────┘
     ↓
┌────────────────────────────────────┐
│  Apply Attention to Values         │
│                                    │
│  Output = Attention · V            │
│                                    │
│  Shape: (seq_len × d_model)        │
└────────────────────────────────────┘
```

### Attention Matrix Visualization
```
         Keys →
Query    The    cat    sat
  ↓     ┌──────┬──────┬──────┐
The     │ 0.33 │ 0.33 │ 0.34 │  ← "The" attends equally to all
        ├──────┼──────┼──────┤
cat     │ 0.10 │ 0.70 │ 0.20 │  ← "cat" focuses on itself
        ├──────┼──────┼──────┤
sat     │ 0.05 │ 0.85 │ 0.10 │  ← "sat" focuses on "cat"
        └──────┴──────┴──────┘
        
Interpretation:
✅ Diagonal (high values): Self-attention
✅ Off-diagonal (high values): Contextual relationships
```

---

## Multi-Head Attention

```
Split embedding dimension across multiple heads
Each head learns different relationships!

Input: (seq_len, d_model)
     │
     ├─────────────┬─────────────┬─────────────┬─────────────┐
     │             │             │             │             │
     ↓             ↓             ↓             ↓             ↓
┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐
│ Head 1  │   │ Head 2  │   │ Head 3  │   │ Head 4  │...│ Head h  │
│         │   │         │   │         │   │         │   │         │
│ Syntax  │   │Semantics│   │ Local   │   │ Long-   │   │ Other   │
│Relations│   │         │   │Context  │   │ Range   │   │Patterns │
└─────────┘   └─────────┘   └─────────┘   └─────────┘   └─────────┘
     │             │             │             │             │
     └─────────────┴─────────────┴─────────────┴─────────────┘
                              ↓
                       CONCATENATE
                              ↓
                    LINEAR PROJECTION
                              ↓
                    Output (seq_len, d_model)

Example with d_model=512, num_heads=8:
• Each head processes 512/8 = 64 dimensions
• 8 parallel attention computations
• Different patterns learned by each head
```

### What Different Heads Learn
```
Head 1:  The    cat    sat
        ┌──────┬──────┬──────┐
        │ 0.8  │ 0.1  │ 0.1  │  Focus on beginning
        │ 0.1  │ 0.8  │ 0.1  │
        │ 0.1  │ 0.1  │ 0.8  │
        └──────┴──────┴──────┘

Head 2:  The    cat    sat
        ┌──────┬──────┬──────┐
        │ 0.2  │ 0.3  │ 0.5  │  Adjacent words
        │ 0.3  │ 0.4  │ 0.3  │
        │ 0.5  │ 0.3  │ 0.2  │
        └──────┴──────┴──────┘

Head 3:  The    cat    sat
        ┌──────┬──────┬──────┐
        │ 0.1  │ 0.8  │ 0.1  │  Subject-verb
        │ 0.1  │ 0.7  │ 0.2  │
        │ 0.2  │ 0.7  │ 0.1  │
        └──────┴──────┴──────┘
```

---

## Complete Transformer Block

```
                    Input X
                       ↓
        ╔══════════════════════════════╗
        ║  MULTI-HEAD ATTENTION        ║
        ║                              ║
        ║  • Creates Q, K, V           ║
        ║  • Computes attention        ║
        ║  • Multiple heads            ║
        ╚══════════════════════════════╝
                       ↓
                  [Output 1]
                       ↓
        ┌──────────────────────────────┐
        │      ADD & NORMALIZE          │
        │                               │
        │   X_1 = LayerNorm(X + Out1)  │
        │                               │
        │   (Residual Connection)       │
        └──────────────────────────────┘
                       ↓
        ╔══════════════════════════════╗
        ║   FEED-FORWARD NETWORK       ║
        ║                              ║
        ║   FFN(x) = max(0, xW₁ + b₁)W₂║
        ║                              ║
        ║   Dimensions:                ║
        ║   d_model → 4*d_model → d_model║
        ╚══════════════════════════════╝
                       ↓
                  [Output 2]
                       ↓
        ┌──────────────────────────────┐
        │      ADD & NORMALIZE          │
        │                               │
        │   X_2 = LayerNorm(X_1 + Out2)│
        │                               │
        │   (Residual Connection)       │
        └──────────────────────────────┘
                       ↓
                 Output X_2
```

### Residual Connections Explained
```
WITHOUT Residual:
    X → [Layer] → Output
    Problem: Information can be lost/distorted

WITH Residual:
    X ─┬→ [Layer] → Output
       │              ↓
       └──────────→ (+)
                    ↓
               X + Output
    
Benefits:
✅ Easier to train deep networks
✅ Gradients flow better
✅ Model can learn identity mapping if needed
```

---

## Full Model Architecture

### GPT-Style (Decoder-Only)
```
Input: "The cat sat"  →  Output: "on"

┌────────────────────────────────────────────┐
│         INPUT PROCESSING                    │
├────────────────────────────────────────────┤
│  Tokens: [101, 245, 389]                   │
│     ↓                                       │
│  Embeddings (seq_len, d_model)             │
│     ↓                                       │
│  + Positional Encoding                     │
└────────────────────────────────────────────┘
              ↓
┌────────────────────────────────────────────┐
│         TRANSFORMER STACK                   │
├────────────────────────────────────────────┤
│  ┌──────────────────────────────────────┐  │
│  │  Layer 1: Multi-Head Attention        │  │
│  │           + FFN                       │  │
│  └──────────────────────────────────────┘  │
│               ↓                            │
│  ┌──────────────────────────────────────┐  │
│  │  Layer 2: Multi-Head Attention        │  │
│  │           + FFN                       │  │
│  └──────────────────────────────────────┘  │
│               ↓                            │
│               ⋮                            │
│               ↓                            │
│  ┌──────────────────────────────────────┐  │
│  │  Layer N: Multi-Head Attention        │  │
│  │           + FFN                       │  │
│  └──────────────────────────────────────┘  │
└────────────────────────────────────────────┘
              ↓
┌────────────────────────────────────────────┐
│         OUTPUT PROCESSING                   │
├────────────────────────────────────────────┤
│  Linear: (d_model) → (vocab_size)          │
│     ↓                                       │
│  Softmax: Convert to probabilities         │
│     ↓                                       │
│  [0.05, 0.10, 0.70, 0.15, ...]            │
│           ↑                                 │
│       "on" has highest probability          │
└────────────────────────────────────────────┘
```

### Causal (Masked) Attention
```
In GPT-style models, prevent looking at future words:

Attention mask for "The cat sat":

         Keys →
Query    The    cat    sat
  ↓     ┌──────┬──────┬──────┐
The     │  ✓   │  ✗   │  ✗   │  ← Can only see "The"
        ├──────┼──────┼──────┤
cat     │  ✓   │  ✓   │  ✗   │  ← Can see "The" and "cat"
        ├──────┼──────┼──────┤
sat     │  ✓   │  ✓   │  ✓   │  ← Can see all previous
        └──────┴──────┴──────┘

✓ = Allowed to attend (0 in mask)
✗ = Blocked (-∞ in mask, becomes 0 after softmax)
```

---

## Key Formulas

### 1. Self-Attention
```
Attention(Q, K, V) = softmax(QK^T / √d_k) · V

Where:
• Q (Query)  = X · W_q
• K (Key)    = X · W_k
• V (Value)  = X · W_v
• d_k = dimension per head
• √d_k = scaling factor (prevents large values)
```

### 2. Multi-Head Attention
```
MultiHead(Q, K, V) = Concat(head₁, ..., head_h) · W_O

head_i = Attention(Q·W_i^Q, K·W_i^K, V·W_i^V)

Where:
• h = number of heads
• W_O = output projection matrix
```

### 3. Positional Encoding
```
PE(pos, 2i)   = sin(pos / 10000^(2i/d_model))
PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))

Where:
• pos = position in sequence
• i = dimension index
• Even dimensions use sine
• Odd dimensions use cosine
```

### 4. Feed-Forward Network
```
FFN(x) = max(0, xW₁ + b₁)W₂ + b₂

Where:
• W₁: (d_model, d_ff)    typically d_ff = 4 * d_model
• W₂: (d_ff, d_model)
• max(0, ·) = ReLU activation
```

### 5. Layer Normalization
```
LayerNorm(x) = γ · (x - μ) / √(σ² + ε) + β

Where:
• μ = mean(x)
• σ² = variance(x)
• γ, β = learnable parameters
• ε = small constant (e.g., 1e-6)
```

### 6. Residual Connection
```
Output = LayerNorm(X + Sublayer(X))

Where Sublayer can be:
• Multi-head attention
• Feed-forward network
```

---

## Size Comparisons

### Dimensions
```
Component           Small    Medium   Large    GPT-3
─────────────────────────────────────────────────────
d_model             256      512      1024     12288
num_heads           4        8        16       96
d_ff                1024     2048     4096     49152
num_layers          6        12       24       96
vocab_size          10K      30K      50K      50K
max_seq_len         512      1024     2048     2048

Parameters          ~10M     ~100M    ~1B      175B
```

### Memory Usage (Rough Estimates)
```
Attention Matrix:
• Shape: (batch, heads, seq_len, seq_len)
• For seq_len=1024, heads=8, batch=1:
  → 1 × 8 × 1024 × 1024 × 4 bytes
  → ~32 MB per attention layer

Total Model Size:
• Small (10M params):  ~40 MB
• Medium (100M):       ~400 MB
• Large (1B):          ~4 GB
• GPT-3 (175B):        ~700 GB
```

---

## Training vs Inference

### Training Mode
```
Input: Full sequence
"The cat sat on the mat"
         ↓
    [Process all at once]
         ↓
Output: Predictions for every position
["cat", "sat", "on", "the", "mat", "."]
         ↓
Compare with actual next words
         ↓
    Calculate loss
         ↓
    Backpropagate
         ↓
    Update weights
```

### Inference Mode (Text Generation)
```
Step 1:
Input: "The cat"
Output: "sat" (highest probability)

Step 2:
Input: "The cat sat"
Output: "on"

Step 3:
Input: "The cat sat on"
Output: "the"

Step 4:
Input: "The cat sat on the"
Output: "mat"

... continue until stop token or max length
```

---

## Common Hyperparameters

### Model Architecture
```
Parameter               Typical Range    Purpose
─────────────────────────────────────────────────────────
d_model                256-12288        Embedding size
num_heads              4-128            Attention heads
num_layers             6-128            Transformer blocks
d_ff                   4*d_model        FFN hidden size
dropout                0.0-0.3          Regularization
vocab_size             10K-100K         Number of tokens
max_seq_len            512-32K          Max input length
```

### Training
```
Parameter               Typical Range    Purpose
─────────────────────────────────────────────────────────
learning_rate          1e-5 to 1e-3     Step size
batch_size             8-512            Samples per update
warmup_steps           1K-10K           LR warmup period
weight_decay           0.0-0.1          Regularization
grad_clip              0.5-5.0          Gradient clipping
```

---

## Attention Patterns in the Wild

### What Real Transformers Learn

```
Early Layers (1-4):
┌────────────────────────────────────┐
│ • Local dependencies                │
│ • Adjacent words                    │
│ • Simple syntax                     │
│                                    │
│ Example: "the" → "cat"             │
│         article → noun             │
└────────────────────────────────────┘

Middle Layers (5-10):
┌────────────────────────────────────┐
│ • Grammatical relationships         │
│ • Subject-verb agreement            │
│ • Phrase boundaries                 │
│                                    │
│ Example: "cat" → "sat"             │
│         subject → verb             │
└────────────────────────────────────┘

Deep Layers (11+):
┌────────────────────────────────────┐
│ • Long-range dependencies           │
│ • Semantic relationships            │
│ • Reasoning patterns                │
│                                    │
│ Example: "cat" → "it" (50 words later)│
│         coreference resolution      │
└────────────────────────────────────┘
```

---

## Tips for Understanding

### 🎯 Key Intuitions

1. **Self-Attention = Weighted Average**
   - Each word becomes a weighted sum of all words
   - Weights determined by relevance (Q·K similarity)

2. **Multi-Head = Multiple Perspectives**
   - Like asking multiple experts
   - Each head specializes in different patterns

3. **Residual Connections = Information Highway**
   - Allows direct paths through the network
   - Makes training deep models possible

4. **Layer Norm = Stability**
   - Keeps values in a reasonable range
   - Prevents training from exploding/vanishing

5. **Position Encoding = Word Order**
   - Compensates for parallel processing
   - Encodes "where" in the sequence

### 🚀 Why Transformers Work

```
Traditional RNNs:
Time 1 → Time 2 → Time 3 → ... → Time N
  ↓        ↓        ↓              ↓
(Sequential, slow, limited context)

Transformers:
Time 1 ─┐
Time 2 ─┤
Time 3 ─┼→ [All interact] → Output
  ...   │
Time N ─┘
(Parallel, fast, unlimited context)
```

---

## Further Reading

### Papers
- "Attention Is All You Need" (Original Transformer, 2017)
- "BERT: Pre-training of Deep Bidirectional Transformers" (2018)
- "Language Models are Few-Shot Learners" (GPT-3, 2020)

### Resources
- The Illustrated Transformer (Jay Alammar)
- Transformer Visualization Tools (BertViz, Attention Flow)
- Hugging Face Transformers Library

---

**Remember**: Transformers are just clever matrix multiplications with learned weights! The "magic" comes from:
1. Learning the right weights (training)
2. Having enough data
3. Using enough parameters
4. Clever architecture (attention, residuals, etc.)

🎉 **You now understand the architecture behind ChatGPT, Claude, and other LLMs!** 🎉
