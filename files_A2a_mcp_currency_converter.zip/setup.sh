#!/bin/bash
###############################################################################
# 💱 Currency Agent Setup Script
###############################################################################
# Automates the setup process for the Currency Exchange Agent with Ollama
#
# Usage:
#   chmod +x setup.sh
#   ./setup.sh
###############################################################################

set -e  # Exit on any error

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     💱 Currency Agent Setup - Ollama Edition                 ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "ℹ️  $1"
}

# Check Python version
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 1: Checking Python Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    print_success "Python found: $PYTHON_VERSION"
else
    print_error "Python 3 not found!"
    print_info "Please install Python 3.8 or higher"
    exit 1
fi

# Check if Ollama is installed
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 2: Checking Ollama Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v ollama &> /dev/null; then
    OLLAMA_VERSION=$(ollama --version 2>&1 || echo "unknown")
    print_success "Ollama found: $OLLAMA_VERSION"
else
    print_warning "Ollama not found!"
    print_info "Installing Ollama..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        curl -fsSL https://ollama.ai/install.sh | sh
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        print_info "For macOS, please install via:"
        print_info "  brew install ollama"
        print_info "Or download from: https://ollama.ai/download"
        exit 1
    else
        print_error "Unsupported OS. Please install Ollama manually:"
        print_info "  https://ollama.ai/download"
        exit 1
    fi
fi

# Check if Ollama is running
print_info "Checking if Ollama server is running..."
if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    print_success "Ollama server is running"
else
    print_warning "Ollama server not running"
    print_info "Starting Ollama in background..."
    ollama serve > /dev/null 2>&1 &
    sleep 3
    
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        print_success "Ollama server started"
    else
        print_error "Could not start Ollama server"
        print_info "Please run: ollama serve"
        exit 1
    fi
fi

# Pull the default model
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 3: Downloading LLM Model"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

DEFAULT_MODEL="llama3.2"

print_info "Checking for model: $DEFAULT_MODEL"

if ollama list | grep -q "$DEFAULT_MODEL"; then
    print_success "Model $DEFAULT_MODEL already downloaded"
else
    print_info "Downloading $DEFAULT_MODEL (this may take a few minutes)..."
    ollama pull $DEFAULT_MODEL
    print_success "Model downloaded successfully"
fi

# Create virtual environment
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 4: Setting Up Python Environment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -d "venv" ]; then
    print_warning "Virtual environment already exists"
    read -p "Recreate it? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf venv
        python3 -m venv venv
        print_success "Virtual environment recreated"
    fi
else
    print_info "Creating virtual environment..."
    python3 -m venv venv
    print_success "Virtual environment created"
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 5: Installing Python Dependencies"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

print_info "Installing required packages..."
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

print_success "All dependencies installed"

# Test the installation
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 6: Testing Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

print_info "Running quick test..."

python3 << EOF
import ollama
import requests

# Test Ollama connection
try:
    ollama.list()
    print("✅ Ollama connection: OK")
except Exception as e:
    print(f"❌ Ollama connection: FAILED - {e}")
    exit(1)

# Test exchange rate API
try:
    response = requests.get("https://api.exchangerate-api.com/v4/latest/USD", timeout=5)
    if response.status_code == 200:
        print("✅ Exchange rate API: OK")
    else:
        print("⚠️  Exchange rate API: Limited (will use fallback)")
except:
    print("⚠️  Exchange rate API: Offline (will use fallback)")

print("✅ All tests passed!")
EOF

if [ $? -eq 0 ]; then
    print_success "Installation test passed!"
else
    print_error "Installation test failed!"
    exit 1
fi

# Final instructions
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║              🎉 Setup Complete!                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "To start using the Currency Agent:"
echo ""
echo "1️⃣  Activate the virtual environment:"
echo "   ${GREEN}source venv/bin/activate${NC}"
echo ""
echo "2️⃣  Run one of the following:"
echo ""
echo "   ${GREEN}python currency_agent_simple.py${NC}"
echo "   └─ Simple CLI version (best for learning)"
echo ""
echo "   ${GREEN}python currency_agent_multi.py${NC}"
echo "   └─ Full multi-agent system"
echo ""
echo "   ${GREEN}python currency_agent_web.py${NC}"
echo "   └─ Web interface (opens at http://localhost:7860)"
echo ""
echo "📚 Documentation: See README.md and docs/ folder"
echo ""
echo "Happy currency converting! 💱"
