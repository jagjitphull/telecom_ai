#!/usr/bin/env python3
"""
💱 Simple Currency Exchange Agent with Ollama
==================================================
Level 1: Basic implementation for learning

This is the STARTING POINT - simple, clear, easy to understand.
Perfect for learning how to build agents with local LLMs!

Features:
- Currency conversion using live rates
- Natural language understanding
- Local LLM via Ollama (no API keys!)
- ~200 lines of straightforward code

Usage:
    python currency_agent_simple.py
"""

import ollama
import requests
import json
import re
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple

class SimpleCurrencyAgent:
    """A straightforward currency agent powered by Ollama"""
    
    def __init__(self, model="llama3.2"):
        """
        Initialize the agent
        
        Args:
            model: Ollama model to use (llama3.2, mistral, phi3, etc.)
        """
        self.model = model
        self.rate_cache = {}
        self.cache_time = None
        print(f"🤖 Initializing Currency Agent with {model}...")
        
        # Verify Ollama is running
        try:
            ollama.list()
            print("✅ Ollama connection successful")
        except Exception as e:
            print(f"❌ Error: Cannot connect to Ollama. Make sure it's running!")
            print(f"   Run: ollama serve")
            raise
    
    def get_exchange_rates(self, base_currency="USD") -> Dict:
        """
        Fetch current exchange rates
        
        Uses free exchangerate-api.com API (no key required for basic use)
        Caches results for 1 hour to minimize API calls
        """
        # Check cache (valid for 1 hour)
        if self.cache_time and \
           datetime.now() - self.cache_time < timedelta(hours=1) and \
           base_currency in self.rate_cache:
            return self.rate_cache[base_currency]
        
        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{base_currency}"
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            
            data = response.json()
            self.rate_cache[base_currency] = data['rates']
            self.cache_time = datetime.now()
            
            return data['rates']
            
        except requests.RequestException as e:
            print(f"⚠️  Warning: Could not fetch live rates. Using mock data.")
            # Return some mock rates for demo purposes
            return {
                "USD": 1.0, "EUR": 0.92, "GBP": 0.79, "JPY": 149.50,
                "CAD": 1.36, "AUD": 1.52, "CHF": 0.88, "CNY": 7.24
            }
    
    def convert_currency(self, amount: float, from_curr: str, 
                        to_curr: str) -> Tuple[float, float]:
        """
        Convert between currencies
        
        Returns:
            (converted_amount, exchange_rate)
        """
        rates = self.get_exchange_rates(from_curr)
        
        if to_curr not in rates:
            raise ValueError(f"Unknown currency: {to_curr}")
        
        rate = rates[to_curr]
        converted = amount * rate
        
        return converted, rate
    
    def extract_conversion_params(self, query: str) -> Optional[Dict]:
        """
        Use LLM to extract conversion parameters from natural language
        
        Examples:
            "Convert 100 USD to EUR" -> {amount: 100, from: USD, to: EUR}
            "How much is 50 euros in dollars?" -> {amount: 50, from: EUR, to: USD}
        """
        prompt = f"""Extract the currency conversion parameters from this query.

Query: "{query}"

Return ONLY a JSON object with these fields:
- amount: numeric amount to convert
- from_currency: source currency code (3 letters, e.g. USD, EUR, GBP)
- to_currency: target currency code (3 letters)

If the query asks for multiple target currencies, use the first one mentioned.
If you cannot extract all parameters, return {{"error": "Could not parse query"}}.

Examples:
Query: "Convert 100 USD to EUR"
{{"amount": 100, "from_currency": "USD", "to_currency": "EUR"}}

Query: "How much is 50 euros in dollars?"
{{"amount": 50, "from_currency": "EUR", "to_currency": "USD"}}

Now extract from the query above. Return ONLY the JSON, nothing else:"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={
                    "temperature": 0.1,  # Low temp for structured output
                    "num_predict": 100,
                }
            )
            
            # Extract JSON from response
            text = response['response'].strip()
            
            # Try to find JSON in the response
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                params = json.loads(json_match.group())
                
                # Validate
                if 'error' in params:
                    return None
                
                # Convert to uppercase
                params['from_currency'] = params['from_currency'].upper()
                params['to_currency'] = params['to_currency'].upper()
                
                return params
            
            return None
            
        except Exception as e:
            print(f"⚠️  Error parsing query: {e}")
            return None
    
    def generate_response(self, query: str, conversion_result: Dict) -> str:
        """
        Use LLM to generate a natural language response
        """
        prompt = f"""You are a helpful currency exchange assistant.

User query: "{query}"

Conversion result:
- Amount: {conversion_result['amount']} {conversion_result['from_currency']}
- Converts to: {conversion_result['converted']:.2f} {conversion_result['to_currency']}
- Exchange rate: 1 {conversion_result['from_currency']} = {conversion_result['rate']:.4f} {conversion_result['to_currency']}

Provide a clear, friendly response to the user. Keep it concise (2-3 sentences).
Include the converted amount and rate.

Response:"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={
                    "temperature": 0.3,
                    "num_predict": 150,
                }
            )
            
            return response['response'].strip()
            
        except Exception as e:
            # Fallback to simple response
            result = conversion_result
            return f"{result['amount']} {result['from_currency']} = {result['converted']:.2f} {result['to_currency']} (rate: {result['rate']:.4f})"
    
    def process_query(self, query: str) -> str:
        """
        Main method: Process a currency query and return response
        """
        print(f"\n💭 Thinking...")
        
        # Step 1: Extract parameters using LLM
        params = self.extract_conversion_params(query)
        
        if not params:
            return "❌ I couldn't understand that query. Please try:\n" + \
                   "   'Convert 100 USD to EUR'\n" + \
                   "   'How much is 50 euros in dollars?'"
        
        # Step 2: Perform conversion
        try:
            converted, rate = self.convert_currency(
                params['amount'],
                params['from_currency'],
                params['to_currency']
            )
            
            result = {
                'amount': params['amount'],
                'from_currency': params['from_currency'],
                'to_currency': params['to_currency'],
                'converted': converted,
                'rate': rate
            }
            
            # Step 3: Generate natural language response
            response = self.generate_response(query, result)
            return response
            
        except ValueError as e:
            return f"❌ Error: {e}"
        except Exception as e:
            return f"❌ Unexpected error: {e}"
    
    def run(self):
        """Run interactive CLI"""
        print("\n" + "="*60)
        print("💱 Currency Exchange Agent (Powered by Ollama)")
        print("="*60)
        print("\nExamples:")
        print("  • Convert 100 USD to EUR")
        print("  • How much is 50 euros in dollars?")
        print("  • What's 1000 yen in pounds?")
        print("\nType 'quit' to exit\n")
        
        while True:
            try:
                query = input("You: ").strip()
                
                if not query:
                    continue
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("\n👋 Goodbye!")
                    break
                
                response = self.process_query(query)
                print(f"\n🤖 Agent: {response}\n")
                
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")


def main():
    """Entry point"""
    import sys
    
    # Check if Ollama model specified
    model = sys.argv[1] if len(sys.argv) > 1 else "llama3.2"
    
    try:
        agent = SimpleCurrencyAgent(model=model)
        agent.run()
    except Exception as e:
        print(f"\n❌ Failed to start agent: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure Ollama is installed: https://ollama.ai/download")
        print("2. Start Ollama: ollama serve")
        print(f"3. Pull the model: ollama pull {model}")
        sys.exit(1)


if __name__ == "__main__":
    main()
