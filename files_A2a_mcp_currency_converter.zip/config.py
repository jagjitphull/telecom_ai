"""
Configuration settings for Currency Agent
"""

# Ollama Settings
OLLAMA_MODEL = "llama3.2"  # Default model
OLLAMA_HOST = "http://localhost:11434"
OLLAMA_TEMPERATURE = 0.1  # Low for structured outputs
OLLAMA_TOP_P = 0.9
OLLAMA_NUM_PREDICT = 512

# Alternative models (uncomment to use)
# OLLAMA_MODEL = "mistral"    # Good balance
# OLLAMA_MODEL = "phi3"       # Lightweight, fast
# OLLAMA_MODEL = "llama3.1"   # Most capable

# Exchange Rate API
EXCHANGE_RATE_API_URL = "https://api.exchangerate-api.com/v4/latest"
RATE_CACHE_DURATION_HOURS = 1  # Cache rates for 1 hour

# Supported currencies (most common)
SUPPORTED_CURRENCIES = [
    "USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD",
    "CNY", "INR", "BRL", "ZAR", "RUB", "KRW", "SGD", "HKD",
    "SEK", "NOK", "DKK", "MXN", "TRY", "AED", "SAR", "THB"
]

# Agent Settings
MAX_RETRIES = 3
TIMEOUT_SECONDS = 10
