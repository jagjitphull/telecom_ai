# 📖 Usage Examples & Patterns

Complete guide to using the Currency Exchange Agent with real examples.

## Table of Contents
1. [Basic Conversions](#basic-conversions)
2. [Multi-Currency Queries](#multi-currency-queries)
3. [Information Queries](#information-queries)
4. [Advanced Patterns](#advanced-patterns)
5. [Programmatic Usage](#programmatic-usage)
6. [Integration Examples](#integration-examples)

---

## Basic Conversions

### Simple Amount Conversion

**Query**: "Convert 100 USD to EUR"

**What Happens**:
1. LLM extracts: `amount=100, from=USD, to=EUR`
2. Fetches current USD/EUR exchange rate
3. Calculates: 100 × 0.925 = 92.50
4. Generates natural response

**Response**:
```
100 USD equals 92.50 EUR at an exchange rate of 0.9250
```

### Natural Language Variations

All of these work:
```
"How much is 100 dollars in euros?"
"100 USD to EUR please"
"I have 100 dollars, what's that in euros?"
"USD 100 = ? EUR"
"Convert one hundred US dollars to euros"
```

The LLM handles the variety!

---

## Multi-Currency Queries

### Multiple Target Currencies

**Query**: "Convert 1000 EUR to USD, GBP, and JPY"

**Response**:
```
Converting 1000 EUR:
• 1,081.00 USD (rate: 1.0810)
• 864.00 GBP (rate: 0.8640)
• 162,850.00 JPY (rate: 162.8500)
```

### Comparison Queries

**Query**: "Which gives more value: 100 USD in EUR or GBP?"

The agent will:
1. Convert 100 USD to EUR
2. Convert 100 USD to GBP
3. Compare and explain

**Response**:
```
100 USD converts to:
• 92.50 EUR
• 79.00 GBP

You get more value in EUR (higher amount).
```

---

## Information Queries

### Currency Knowledge

**Query**: "What is the strongest currency?"

**Response** (from Info Agent):
```
The Kuwaiti Dinar (KWD) is currently the strongest currency by 
exchange rate value. However, "strength" can also refer to 
stability - in which case, the Swiss Franc (CHF) and Singapore 
Dollar (SGD) are known for their stability.
```

### Concept Explanations

**Query**: "How do exchange rates work?"

**Response**:
```
Exchange rates represent how much one currency is worth in 
terms of another. They fluctuate based on supply and demand, 
economic factors, interest rates, and political stability. 
For example, if demand for USD increases globally, its value 
rises relative to other currencies.
```

### Travel Advice

**Query**: "What's the best currency for traveling to Asia?"

**Response**:
```
For traveling in Asia, consider:

1. US Dollar (USD) - Widely accepted and easily exchanged
2. Singapore Dollar (SGD) - Strong and stable for Southeast Asia
3. Japanese Yen (JPY) - Essential for Japan
4. Local currencies - Often best rates for specific countries

Tip: Always have some local currency for small purchases!
```

---

## Advanced Patterns

### Contextual Follow-up

**First Query**: "Convert 500 USD to EUR"

**Response**: "500 USD = 462.50 EUR"

**Follow-up**: "And to GBP?"

**Response**: "500 USD = 395.00 GBP"

The agent maintains context!

### Historical Comparisons

**Query**: "Has the EUR strengthened or weakened against USD recently?"

**Response** (if analysis agent is available):
```
Based on recent trends:
- 1 month ago: 1 EUR = 1.085 USD
- Today: 1 EUR = 1.081 USD
- Change: -0.37% (slight weakening)

The EUR has weakened slightly against USD over the past month.
```

### Rate Alerts (Future Feature)

**Query**: "Alert me when EUR/USD reaches 1.10"

**Response**:
```
I've set an alert for EUR/USD >= 1.10
Current rate: 1.081
I'll notify you when it hits your target!
```

---

## Programmatic Usage

### Using as a Python Library

```python
from currency_agent_simple import SimpleCurrencyAgent

# Initialize
agent = SimpleCurrencyAgent(model="llama3.2")

# Single query
response = agent.process_query("Convert 100 USD to EUR")
print(response)
# Output: "100 USD equals 92.50 EUR..."

# Batch processing
queries = [
    "Convert 100 USD to EUR",
    "Convert 50 GBP to JPY",
    "Convert 1000 CAD to AUD"
]

for query in queries:
    response = agent.process_query(query)
    print(f"{query} -> {response}\n")
```

### Direct Conversion (Bypass LLM)

```python
from currency_agent_simple import SimpleCurrencyAgent

agent = SimpleCurrencyAgent()

# Direct conversion without LLM
converted, rate = agent.convert_currency(
    amount=100,
    from_curr="USD",
    to_curr="EUR"
)

print(f"Amount: {converted:.2f}")
print(f"Rate: {rate:.4f}")
```

### Using the Multi-Agent System

```python
from currency_agent_multi import OrchestratorAgent

# Initialize orchestrator
orchestrator = OrchestratorAgent(model="llama3.2")

# Process various query types
queries = [
    "Convert 100 USD to EUR",          # -> Converter Agent
    "What is a strong currency?",      # -> Info Agent
    "Hello!",                          # -> Greeting handler
]

for query in queries:
    response = orchestrator.process(query)
    print(f"Q: {query}")
    print(f"A: {response}\n")
```

---

## Integration Examples

### Flask API Integration

```python
from flask import Flask, request, jsonify
from currency_agent_simple import SimpleCurrencyAgent

app = Flask(__name__)
agent = SimpleCurrencyAgent()

@app.route('/convert', methods=['POST'])
def convert():
    data = request.json
    query = data.get('query', '')
    
    response = agent.process_query(query)
    
    return jsonify({
        'query': query,
        'response': response,
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    app.run(port=5000)
```

**Usage**:
```bash
curl -X POST http://localhost:5000/convert \
  -H "Content-Type: application/json" \
  -d '{"query": "Convert 100 USD to EUR"}'
```

### Discord Bot Integration

```python
import discord
from currency_agent_simple import SimpleCurrencyAgent

client = discord.Client()
agent = SimpleCurrencyAgent()

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    
    if message.content.startswith('!convert'):
        query = message.content[9:]  # Remove '!convert '
        response = agent.process_query(query)
        await message.channel.send(response)

client.run('YOUR_BOT_TOKEN')
```

### Slack Bot Integration

```python
from slack_bolt import App
from currency_agent_simple import SimpleCurrencyAgent

app = App(token="xoxb-your-token")
agent = SimpleCurrencyAgent()

@app.message("convert")
def handle_convert(message, say):
    query = message['text']
    response = agent.process_query(query)
    say(response)

if __name__ == "__main__":
    app.start(port=3000)
```

---

## Best Practices

### 1. Cache Warming

```python
# Pre-fetch common currencies on startup
agent = SimpleCurrencyAgent()

# Warm up cache
common_bases = ["USD", "EUR", "GBP", "JPY"]
for base in common_bases:
    agent.get_exchange_rates(base)
```

### 2. Error Handling

```python
try:
    response = agent.process_query(query)
except ValueError as e:
    # Handle invalid currency codes
    response = f"Error: {e}"
except requests.RequestException as e:
    # Handle API failures
    response = "Service temporarily unavailable"
except Exception as e:
    # Handle unexpected errors
    response = "An error occurred"
    logger.error(f"Unexpected error: {e}")
```

### 3. Rate Limiting

```python
from functools import lru_cache
from time import time

@lru_cache(maxsize=100)
def rate_limited_query(query: str, timestamp: int):
    """Cache identical queries for 60 seconds"""
    return agent.process_query(query)

# Usage
response = rate_limited_query(query, int(time() // 60))
```

### 4. Async Processing

```python
import asyncio

async def process_queries_async(queries: list):
    """Process multiple queries concurrently"""
    tasks = [
        asyncio.to_thread(agent.process_query, q)
        for q in queries
    ]
    responses = await asyncio.gather(*tasks)
    return responses

# Usage
queries = ["Convert 100 USD to EUR", "Convert 50 GBP to JPY"]
responses = asyncio.run(process_queries_async(queries))
```

---

## Performance Tips

### Speed Optimization

```python
# Use faster model
agent = SimpleCurrencyAgent(model="phi3")

# Reduce output length
# In config.py: OLLAMA_NUM_PREDICT = 256

# Pre-load model
ollama.generate(model="phi3", prompt="warm up")
```

### Quality Optimization

```python
# Use better model
agent = SimpleCurrencyAgent(model="llama3.1")

# Increase output quality
# In config.py: OLLAMA_NUM_PREDICT = 1024

# Lower temperature for more focused responses
# In config.py: OLLAMA_TEMPERATURE = 0.1
```

---

## Testing Examples

### Unit Test

```python
def test_conversion():
    agent = SimpleCurrencyAgent()
    
    # Test direct conversion
    converted, rate = agent.convert_currency(100, "USD", "EUR")
    
    assert converted > 0, "Converted amount should be positive"
    assert rate > 0, "Exchange rate should be positive"
    assert converted == 100 * rate, "Math should be correct"
```

### Integration Test

```python
def test_query_processing():
    agent = SimpleCurrencyAgent()
    
    queries = [
        "Convert 100 USD to EUR",
        "How much is 50 GBP in USD?",
        "1000 JPY to EUR"
    ]
    
    for query in queries:
        response = agent.process_query(query)
        assert response, f"Should get response for: {query}"
        assert "USD" in response or "EUR" in response or "GBP" in response
```

---

## Common Patterns Summary

| Pattern | Example | Agent Used |
|---------|---------|------------|
| Simple conversion | "100 USD to EUR" | Converter |
| Multi-target | "100 USD to EUR and GBP" | Converter |
| Information | "What is a strong currency?" | Info |
| Comparison | "Better: EUR or GBP?" | Converter + Info |
| Explanation | "How rates work?" | Info |
| Contextual | "And in GBP?" (follow-up) | Context-aware |

---

## Next Steps

- Explore the code in `currency_agent_simple.py`
- Try modifying prompts for different response styles
- Build your own integration
- Add new agent capabilities

---

**Pro Tip**: The system is designed to be extended. Study the examples above and adapt them to your specific use case!
