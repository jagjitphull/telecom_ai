# 💱 Currency Exchange Agent with Ollama

A sophisticated multi-agent system for currency conversion and financial information retrieval using **local LLMs via Ollama** - no API keys required!

## ✨ Features

- 🔄 **Real-time currency conversion** using live exchange rates
- 🤖 **Local LLM inference** with Ollama (privacy-first, no external APIs)
- 🎯 **Multi-agent architecture** with specialized agents for different tasks
- 📊 **Historical rate analysis** and trend visualization
- 🌍 **Support for 150+ currencies**
- 💬 **Natural language interface** - just ask in plain English
- 🚀 **Multiple implementations** - CLI, Web UI, and API versions

## 🚀 Quick Start

### 1. Install Ollama
```bash
# Linux
curl -fsSL https://ollama.ai/install.sh | sh

# macOS  
brew install ollama

# Windows - Download from https://ollama.ai/download
```

### 2. Pull a Model
```bash
ollama pull llama3.2
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Agent
```bash
# Simple CLI version (START HERE)
python currency_agent_simple.py

# Multi-agent system
python currency_agent_multi.py

# Web interface
python currency_agent_web.py
```

## 💡 Usage Examples

```
You: Convert 100 USD to EUR
Agent: 100 USD = 92.50 EUR (rate: 0.925)

You: What's the best currency for travel to Japan?
Agent: For Japan, you'll need Japanese Yen (JPY)...

You: Compare 1000 EUR to USD, GBP, and JPY
Agent: 1000 EUR equals:
       • 1,081.00 USD
       • 864.00 GBP  
       • 162,850.00 JPY
```

## 📁 Project Structure

```
currency-agent-ollama/
├── currency_agent_simple.py      # 🟢 Basic CLI (start here!)
├── currency_agent_multi.py       # 🟡 Full multi-agent system
├── currency_agent_web.py         # 🔵 Gradio web UI
├── agents/                       # Specialized agents
├── tools/                        # Exchange rate tools
└── utils/                        # Ollama integration
```

## 🎯 Implementation Levels

| Version | Complexity | Features | Best For |
|---------|-----------|----------|----------|
| Simple | ⭐ | Basic conversion | Learning |
| Multi-Agent | ⭐⭐⭐ | Full features | Production |
| Web UI | ⭐⭐ | Visual interface | Demos |

## 🛠️ Configuration

```python
# config.py
OLLAMA_MODEL = "llama3.2"  # or mistral, phi3
OLLAMA_TEMPERATURE = 0.1    # Lower = more focused
```

## 📚 Learn More

- See `/docs` for detailed documentation
- Check `currency_agent_simple.py` for starter code
- Read `ARCHITECTURE.md` for system design

---

**🔒 Privacy-First**: All LLM processing happens locally with Ollama!
