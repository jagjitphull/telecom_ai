#!/usr/bin/env python3
"""
💱 Multi-Agent Currency System with Ollama
============================================
Level 2: Production-ready multi-agent architecture

This demonstrates a sophisticated agent system with:
- Orchestrator agent (routes queries)
- Specialized agents (conversion, info, analysis)
- Tool integration (exchange rates, caching)
- Context management

Usage:
    python currency_agent_multi.py
"""

import ollama
import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass

@dataclass
class Message:
    """Represents a message in the conversation"""
    role: str  # 'user', 'agent', 'system'
    content: str
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


class BaseAgent:
    """Base class for all agents"""
    
    def __init__(self, name: str, description: str, model="llama3.2"):
        self.name = name
        self.description = description
        self.model = model
    
    def process(self, query: str, context: Dict = None) -> str:
        """Process a query and return response"""
        raise NotImplementedError


class CurrencyConverterAgent(BaseAgent):
    """Agent specialized in currency conversions"""
    
    def __init__(self, model="llama3.2"):
        super().__init__(
            name="currency_converter",
            description="Converts amounts between different currencies",
            model=model
        )
        self.rate_cache = {}
        self.cache_time = None
    
    def get_rates(self, base="USD") -> Dict:
        """Fetch exchange rates with caching"""
        if self.cache_time and \
           datetime.now() - self.cache_time < timedelta(hours=1) and \
           base in self.rate_cache:
            return self.rate_cache[base]
        
        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{base}"
            response = requests.get(url, timeout=5)
            data = response.json()
            
            self.rate_cache[base] = data['rates']
            self.cache_time = datetime.now()
            return data['rates']
        except:
            # Fallback rates
            return {"USD": 1.0, "EUR": 0.92, "GBP": 0.79, "JPY": 149.50}
    
    def convert(self, amount: float, from_curr: str, to_curr: str) -> Dict:
        """Perform currency conversion"""
        rates = self.get_rates(from_curr)
        rate = rates.get(to_curr, 0)
        converted = amount * rate
        
        return {
            "amount": amount,
            "from": from_curr,
            "to": to_curr,
            "converted": converted,
            "rate": rate
        }
    
    def process(self, query: str, context: Dict = None) -> str:
        """Process conversion query"""
        # Extract parameters using LLM
        prompt = f"""Extract conversion parameters from: "{query}"

Return JSON with: amount, from_currency (3-letter code), to_currency (3-letter code).
If multiple target currencies, include all in a "to_currencies" array.

JSON only:"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={"temperature": 0.1, "num_predict": 150}
            )
            
            import re
            json_match = re.search(r'\{.*\}', response['response'], re.DOTALL)
            if json_match:
                params = json.loads(json_match.group())
                
                # Handle single or multiple targets
                to_currencies = params.get('to_currencies', [params.get('to_currency')])
                results = []
                
                for to_curr in to_currencies:
                    result = self.convert(
                        params['amount'],
                        params['from_currency'].upper(),
                        to_curr.upper()
                    )
                    results.append(result)
                
                # Format response
                if len(results) == 1:
                    r = results[0]
                    return f"{r['amount']} {r['from']} = {r['converted']:.2f} {r['to']} (rate: {r['rate']:.4f})"
                else:
                    output = [f"Converting {results[0]['amount']} {results[0]['from']}:"]
                    for r in results:
                        output.append(f"  • {r['converted']:.2f} {r['to']} (rate: {r['rate']:.4f})")
                    return "\n".join(output)
                    
        except Exception as e:
            return f"❌ Conversion error: {e}"


class InformationAgent(BaseAgent):
    """Agent that provides information about currencies"""
    
    def __init__(self, model="llama3.2"):
        super().__init__(
            name="info_agent",
            description="Provides information about currencies and financial concepts",
            model=model
        )
    
    def process(self, query: str, context: Dict = None) -> str:
        """Answer informational questions"""
        prompt = f"""You are a currency and finance expert. Answer this question clearly and concisely:

Question: {query}

Provide a helpful answer in 2-3 sentences. Focus on practical information.

Answer:"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={"temperature": 0.3, "num_predict": 300}
            )
            return response['response'].strip()
        except Exception as e:
            return f"❌ Error: {e}"


class OrchestratorAgent(BaseAgent):
    """Main orchestrator that routes queries to specialized agents"""
    
    def __init__(self, model="llama3.2"):
        super().__init__(
            name="orchestrator",
            description="Routes queries to appropriate specialized agents",
            model=model
        )
        
        # Initialize specialized agents
        self.converter = CurrencyConverterAgent(model)
        self.info_agent = InformationAgent(model)
        
        self.conversation_history: List[Message] = []
    
    def route_query(self, query: str) -> str:
        """Determine which agent should handle the query"""
        prompt = f"""Classify this user query:

Query: "{query}"

Categories:
- conversion: User wants to convert currency amounts
- information: User asks about currencies, rates, or concepts
- greeting: User is greeting or chatting

Return ONLY the category name (one word):"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={"temperature": 0.1, "num_predict": 20}
            )
            
            category = response['response'].strip().lower()
            return category
            
        except:
            return "conversion"  # Default
    
    def process(self, query: str, context: Dict = None) -> str:
        """Main processing method"""
        # Add to history
        self.conversation_history.append(Message("user", query))
        
        # Route to appropriate agent
        category = self.route_query(query)
        
        if "conversion" in category or "convert" in category:
            response = self.converter.process(query, context)
        elif "information" in category or "info" in category:
            response = self.info_agent.process(query, context)
        elif "greeting" in category or "hello" in category:
            response = "Hello! I'm your currency exchange assistant. I can help you convert currencies or answer questions about exchange rates. What would you like to know?"
        else:
            # Try conversion as default
            response = self.converter.process(query, context)
        
        # Add response to history
        self.conversation_history.append(Message("agent", response))
        
        return response
    
    def run_cli(self):
        """Run interactive CLI"""
        print("\n" + "="*70)
        print("💱 Multi-Agent Currency System (Powered by Ollama)")
        print("="*70)
        print("\n🤖 Active Agents:")
        print("  • Orchestrator - Routes your queries")
        print("  • Converter - Handles currency conversions")
        print("  • Info Agent - Answers questions about currencies")
        print("\n💡 Try:")
        print("  • Convert 100 USD to EUR and GBP")
        print("  • What's the strongest currency in the world?")
        print("  • How do exchange rates work?")
        print("\nType 'quit' to exit, 'history' to see conversation\n")
        
        while True:
            try:
                query = input("You: ").strip()
                
                if not query:
                    continue
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("\n👋 Goodbye!")
                    break
                
                if query.lower() == 'history':
                    print("\n📜 Conversation History:")
                    for msg in self.conversation_history[-10:]:  # Last 10
                        time = msg.timestamp.strftime("%H:%M:%S")
                        print(f"  [{time}] {msg.role}: {msg.content[:80]}...")
                    print()
                    continue
                
                print(f"\n💭 Processing...")
                response = self.process(query)
                print(f"\n🤖 Agent: {response}\n")
                
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")


def main():
    """Entry point"""
    import sys
    
    model = sys.argv[1] if len(sys.argv) > 1 else "llama3.2"
    
    print(f"🚀 Starting Multi-Agent System with {model}...")
    
    try:
        orchestrator = OrchestratorAgent(model=model)
        orchestrator.run_cli()
    except Exception as e:
        print(f"\n❌ Failed to start: {e}")
        print("\nMake sure:")
        print("  1. Ollama is running: ollama serve")
        print(f"  2. Model is pulled: ollama pull {model}")
        sys.exit(1)


if __name__ == "__main__":
    main()
