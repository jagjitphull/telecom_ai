# 🗺️ CURRENCY AGENT - Master Navigation Index

## 🎯 START HERE

### New to this project? Follow these 3 steps:

1. **Read** [README.md](README.md) (5 minutes)
2. **Run** `./setup.sh` (5 minutes)  
3. **Try** `python currency_agent_simple.py` (start asking questions!)

---

## 📁 What's in This Package?

A complete **Currency Exchange Agent** powered by **Ollama** (local LLMs) - no API keys, full privacy!

### Three Implementations (Pick Your Level)

| File | Level | When to Use |
|------|-------|-------------|
| `currency_agent_simple.py` | ⭐ Beginner | Learning & understanding basics |
| `currency_agent_multi.py` | ⭐⭐ Advanced | Production multi-agent system |
| `currency_agent_web.py` | ⭐⭐⭐ User-Friendly | Beautiful web interface |

---

## 📚 Documentation Quick Links

### Getting Started
- **[README.md](README.md)** - Project overview & features
- **[docs/QUICKSTART.md](docs/QUICKSTART.md)** - 5-minute setup guide
- **[setup.sh](setup.sh)** - Automated installation script

### Learning
- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** - How the system works
- **[docs/EXAMPLES.md](docs/EXAMPLES.md)** - Usage patterns & code examples
- **[docs/PACKAGE_SUMMARY.md](docs/PACKAGE_SUMMARY.md)** - Complete package overview

### Configuration
- **[config.py](config.py)** - Settings (model, temperature, etc.)
- **[requirements.txt](requirements.txt)** - Python dependencies

---

## 🚀 Quick Start Commands

```bash
# One-command setup (recommended)
./setup.sh

# Then run one of these:
python currency_agent_simple.py    # Simple CLI
python currency_agent_multi.py     # Multi-agent system
python currency_agent_web.py       # Web interface → http://localhost:7860
```

---

## 🎓 Learning Path

### Day 1: Run & Understand
1. Run `./setup.sh`
2. Try `python currency_agent_simple.py`
3. Read `currency_agent_simple.py` source code (~200 lines)
4. Experiment with different queries

### Day 2-3: Deep Dive
1. Read `docs/ARCHITECTURE.md`
2. Run `currency_agent_multi.py`
3. Study the multi-agent patterns
4. Explore `docs/EXAMPLES.md`

### Week 1+: Build & Extend
1. Modify prompts for different styles
2. Add your own agent types
3. Integrate with your applications
4. Share your creations!

---

## 🔍 Find What You Need

| I Want To... | Go To... |
|--------------|----------|
| Get started NOW | Run `./setup.sh` |
| Understand the system | `docs/ARCHITECTURE.md` |
| See usage examples | `docs/EXAMPLES.md` |
| Change the model | Edit `config.py` |
| Build my own agent | Study `currency_agent_multi.py` |
| Integrate in my app | `docs/EXAMPLES.md` → Integration section |
| Troubleshoot issues | `docs/QUICKSTART.md` → Troubleshooting |
| Web interface | Run `currency_agent_web.py` |

---

## 📊 File Structure Overview

```
currency-agent-ollama/
├── 📄 README.md                    # ⭐ Start here
├── 🔧 setup.sh                     # Auto-installer
├── 📦 requirements.txt             # Dependencies
├── ⚙️  config.py                   # Settings
│
├── 🐍 Implementations
│   ├── currency_agent_simple.py   # Level 1 (~200 lines)
│   ├── currency_agent_multi.py    # Level 2 (~300 lines)
│   └── currency_agent_web.py      # Level 3 (~250 lines)
│
├── 📚 docs/
│   ├── QUICKSTART.md              # Setup guide
│   ├── ARCHITECTURE.md            # System design
│   ├── EXAMPLES.md                # Usage patterns
│   └── PACKAGE_SUMMARY.md         # Package overview
│
└── 🤖 Optional Extensions
    ├── agents/                    # Custom agents
    ├── tools/                     # Helper tools
    └── utils/                     # Utilities
```

---

## 💡 Key Features

✅ **Local LLM Processing** - Privacy-first with Ollama  
✅ **No API Keys Required** - Everything runs locally  
✅ **Multi-Agent Architecture** - Production-ready patterns  
✅ **Natural Language** - Ask in plain English  
✅ **Real-Time Rates** - Live exchange rate data  
✅ **Multiple Interfaces** - CLI, Multi-agent, Web UI  
✅ **Educational Design** - Learn by reading clear code  
✅ **Extensible** - Easy to add new features  

---

## 🎯 Common Questions

### Q: Which file should I start with?
**A:** `currency_agent_simple.py` - it's simple, clear, and only 200 lines!

### Q: Do I need API keys?
**A:** No! Everything uses local Ollama for LLM processing.

### Q: What models can I use?
**A:** llama3.2 (default), mistral, phi3, llama3.1 - edit `config.py` to change.

### Q: How do I install Ollama?
**A:** Run `./setup.sh` - it handles everything automatically!

### Q: Can I use this commercially?
**A:** Yes! MIT License - free for personal and commercial use.

---

## 🆘 Troubleshooting

### Setup Issues?
```bash
# Run the automated setup
./setup.sh

# Check Ollama is running
curl http://localhost:11434/api/tags

# Verify model is downloaded
ollama list
```

### Runtime Issues?
See detailed troubleshooting in: **[docs/QUICKSTART.md](docs/QUICKSTART.md)**

---

## 🎓 What You'll Learn

- ✅ Multi-agent system architecture
- ✅ Local LLM integration with Ollama
- ✅ Prompt engineering techniques
- ✅ Tool integration patterns
- ✅ Context management
- ✅ Production-ready error handling
- ✅ API integration with caching
- ✅ Building conversational AI

---

## 📈 Next Steps

1. **Get it running** - Follow the Quick Start above
2. **Read the code** - Start with `currency_agent_simple.py`
3. **Understand the design** - Read `docs/ARCHITECTURE.md`
4. **Try examples** - Explore `docs/EXAMPLES.md`
5. **Build your own** - Use the patterns to create something new!

---

## 🎉 Ready to Start?

```bash
./setup.sh && python currency_agent_simple.py
```

**Time to first working agent**: ~5 minutes!

---

**Need Help?** All documentation is in the `docs/` folder. Every file has extensive comments. Read them!

**Happy Learning!** 🚀🤖💱
