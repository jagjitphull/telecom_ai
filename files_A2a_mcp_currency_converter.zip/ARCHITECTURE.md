# 🏗️ Architecture Documentation

## System Overview

The Currency Exchange Agent is a multi-agent system that leverages local LLMs via Ollama to provide natural language currency conversion and financial information services.

## Design Principles

### 1. **Local-First Processing**
- All LLM inference happens locally via Ollama
- No external API keys required for AI processing
- Privacy-preserving: user queries never leave the machine

### 2. **Agent-Based Architecture**
- Modular design with specialized agents
- Clear separation of concerns
- Easy to extend with new agents

### 3. **Progressive Complexity**
- Simple version for learning (currency_agent_simple.py)
- Full-featured for production (currency_agent_multi.py)
- User-friendly web interface (currency_agent_web.py)

## Architecture Diagrams

### Level 1: Simple Agent

```
┌─────────────────────────────────────────────────┐
│                                                 │
│              Simple Currency Agent              │
│                                                 │
│  ┌────────────────────────────────────────┐    │
│  │                                        │    │
│  │  Query Processing                      │    │
│  │  ├─ Extract parameters (via LLM)       │    │
│  │  ├─ Fetch exchange rates              │    │
│  │  ├─ Perform conversion                │    │
│  │  └─ Generate response (via LLM)       │    │
│  │                                        │    │
│  └────────────────────────────────────────┘    │
│                                                 │
└─────────────────────────────────────────────────┘
            ↓                   ↓
      ┌──────────┐        ┌──────────┐
      │  Ollama  │        │ Rate API │
      └──────────┘        └──────────┘
```

### Level 2: Multi-Agent System

```
┌───────────────────────────────────────────────────────────────┐
│                      Orchestrator Agent                       │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │           Query Router (LLM-based)                   │    │
│  │  • Classifies intent (conversion/info/greeting)      │    │
│  │  • Routes to appropriate specialized agent           │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│            ↓                  ↓                 ↓             │
│    ┌──────────────┐   ┌──────────────┐  ┌──────────────┐    │
│    │  Converter   │   │     Info     │  │   Analysis   │    │
│    │    Agent     │   │    Agent     │  │    Agent     │    │
│    │              │   │              │  │              │    │
│    │ • Extracts   │   │ • Answers    │  │ • Historical │    │
│    │   params     │   │   questions  │  │   trends     │    │
│    │ • Converts   │   │ • Explains   │  │ • Insights   │    │
│    │   currency   │   │   concepts   │  │ • Graphs     │    │
│    └──────────────┘   └──────────────┘  └──────────────┘    │
│            ↓                  ↓                 ↓             │
└───────────────────────────────────────────────────────────────┘
                                ↓
                    ┌────────────────────────┐
                    │    Shared Tools        │
                    │                        │
                    │  • Exchange Rate API   │
                    │  • Rate Cache (SQLite) │
                    │  • Currency Metadata   │
                    └────────────────────────┘
                                ↓
                    ┌────────────────────────┐
                    │    Ollama LLM          │
                    │  (llama3.2/mistral)    │
                    └────────────────────────┘
```

## Component Description

### Agents

#### Orchestrator Agent
**Role**: Main coordinator and query router

**Responsibilities**:
- Receives all user queries
- Classifies intent using LLM
- Routes to specialized agents
- Maintains conversation context
- Aggregates responses

**Key Methods**:
```python
route_query(query: str) -> str
    # Uses LLM to determine which agent should handle query
    
process(query: str) -> str
    # Main processing pipeline
```

#### Currency Converter Agent
**Role**: Handles all currency conversion requests

**Responsibilities**:
- Extracts conversion parameters (amount, from, to)
- Fetches live exchange rates
- Performs calculations
- Formats responses

**Key Methods**:
```python
convert(amount: float, from_curr: str, to_curr: str) -> Dict
    # Core conversion logic
    
process(query: str) -> str
    # Handle conversion queries
```

#### Information Agent
**Role**: Answers questions about currencies and finance

**Responsibilities**:
- Explains currency concepts
- Provides historical context
- Answers "what is" type questions
- Educational content

**Key Methods**:
```python
process(query: str) -> str
    # Answer informational queries using LLM
```

### Tools

#### Exchange Rate Tool
**Purpose**: Fetch live currency exchange rates

**Features**:
- Free tier API (no key required)
- Rate caching (1 hour TTL)
- Fallback to mock data
- Support for 150+ currencies

**API Used**: https://api.exchangerate-api.com/v4/latest/{BASE}

#### Rate Cache
**Purpose**: Minimize API calls and improve performance

**Implementation**:
- In-memory cache with TTL
- Optional SQLite persistence
- Automatic cache invalidation

### Utilities

#### Ollama Client
**Purpose**: Wrapper for Ollama API interactions

**Features**:
- Connection management
- Model verification
- Error handling
- Response parsing

**Key Functions**:
```python
generate_completion(prompt: str, model: str) -> str
    # Generate LLM completion
    
extract_json(response: str) -> Dict
    # Parse JSON from LLM output
```

## Data Flow

### Conversion Query Example

```
User: "Convert 100 USD to EUR"
   ↓
[Orchestrator receives query]
   ↓
[LLM classifies as "conversion"]
   ↓
[Routes to Converter Agent]
   ↓
[Converter uses LLM to extract: amount=100, from=USD, to=EUR]
   ↓
[Fetches exchange rate from cache/API]
   ↓
[Calculates: 100 * 0.92 = 92.00]
   ↓
[LLM generates natural language response]
   ↓
Agent: "100 USD equals 92.00 EUR at a rate of 0.9200"
```

### Information Query Example

```
User: "What is a good travel currency?"
   ↓
[Orchestrator receives query]
   ↓
[LLM classifies as "information"]
   ↓
[Routes to Info Agent]
   ↓
[Info Agent uses LLM with financial knowledge]
   ↓
Agent: "For travel, consider major stable currencies like USD, EUR, or GBP..."
```

## LLM Integration Strategy

### Prompt Engineering

The system uses carefully crafted prompts for different tasks:

#### Parameter Extraction
```
Extract conversion parameters from: "{query}"

Return JSON with: amount, from_currency, to_currency
```

**Why it works**:
- Clear, structured format
- JSON output for easy parsing
- Specific field names
- Low temperature (0.1) for consistency

#### Response Generation
```
You are a currency assistant.
User query: "{query}"
Result: {data}

Provide a clear, friendly response...
```

**Why it works**:
- Context provided upfront
- Friendly tone instruction
- Length guidance
- Higher temperature (0.3) for natural language

### Model Selection Guide

| Model | Size | Speed | Quality | Best For |
|-------|------|-------|---------|----------|
| llama3.2 | 3B | Fast | Good | Production |
| mistral | 7B | Medium | Better | Balanced |
| phi3 | 3.8B | Fast | Good | Resource-limited |
| llama3.1 | 8B | Slow | Best | Accuracy-critical |

## Scalability Considerations

### Current Implementation
- Single-threaded
- In-memory cache
- Local processing only

### Production Enhancements
1. **Async Processing**
   - Use asyncio for concurrent requests
   - Non-blocking I/O operations

2. **Distributed Cache**
   - Redis for shared cache
   - Rate limiting by user

3. **API Gateway**
   - REST API with Flask/FastAPI
   - Authentication & rate limiting

4. **Monitoring**
   - Log all queries
   - Track agent performance
   - Monitor API usage

## Security Considerations

### Current Security
✅ Local LLM (no data sent to external AI services)
✅ No API keys stored in code
✅ Input validation on currency codes
✅ Request timeouts

### Production Requirements
- [ ] Input sanitization
- [ ] Rate limiting per user
- [ ] Authentication system
- [ ] Audit logging
- [ ] HTTPS for API endpoints

## Extension Points

### Adding New Agents

```python
class CustomAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="custom_agent",
            description="What this agent does"
        )
    
    def process(self, query: str, context: Dict) -> str:
        # Implementation
        pass

# Register in orchestrator
orchestrator.register_agent(CustomAgent())
```

### Adding New Tools

```python
class CustomTool:
    def execute(self, **params):
        # Tool logic
        return result

# Use in agent
tool = CustomTool()
result = tool.execute(param1="value")
```

## Performance Optimization

### Caching Strategy
1. **Rate Cache**: 1 hour TTL
2. **LLM Response Cache**: For repeated queries
3. **Model Loading**: Keep model warm

### Latency Breakdown
- LLM parameter extraction: ~500ms
- Exchange rate fetch: ~200ms (cached: ~1ms)
- LLM response generation: ~800ms
- **Total**: ~1.5 seconds

### Optimization Techniques
1. Use smaller models (phi3 vs llama3.1)
2. Reduce `num_predict` parameter
3. Implement response caching
4. Pre-warm model on startup

## Testing Strategy

### Unit Tests
- Agent logic
- Tool functions
- Prompt templates

### Integration Tests
- End-to-end flows
- API interactions
- Error handling

### Example Test
```python
def test_conversion():
    agent = CurrencyConverterAgent()
    result = agent.convert(100, "USD", "EUR")
    assert result['converted'] > 0
    assert result['rate'] > 0
```

## Deployment Options

### Local Development
```bash
python currency_agent_simple.py
```

### Web Interface
```bash
python currency_agent_web.py
# Access at http://localhost:7860
```

### API Server
```bash
python currency_agent_api.py
# REST API at http://localhost:5000
```

### Docker Container
```dockerfile
FROM python:3.10
# Install Ollama
# Copy code
# Run agent
```

## Future Enhancements

### Planned Features
- [ ] Historical rate charts
- [ ] Cryptocurrency support
- [ ] Rate alerts/notifications
- [ ] Multi-language support
- [ ] Voice interface
- [ ] Mobile app

### Advanced Agent Capabilities
- [ ] Predictive analytics
- [ ] Sentiment analysis of currency news
- [ ] Portfolio management
- [ ] Automated trading signals

---

**Last Updated**: 2024
**Version**: 1.0
**Maintainer**: AI Learning Community
