#!/usr/bin/env python3
"""
💱 Currency Agent Web Interface with Gradio
=============================================
Level 3: User-friendly web interface

Beautiful, interactive web UI for currency conversions
Powered by Ollama for local LLM processing

Usage:
    python currency_agent_web.py
    
    Then open: http://localhost:7860
"""

try:
    import gradio as gr
except ImportError:
    print("❌ Gradio not installed. Install it with:")
    print("   pip install gradio")
    exit(1)

import ollama
import requests
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Tuple


class CurrencyAgentWeb:
    """Web-based currency agent"""
    
    def __init__(self, model="llama3.2"):
        self.model = model
        self.rate_cache = {}
        self.cache_time = None
        self.chat_history = []
        
        # Verify Ollama
        try:
            ollama.list()
            print(f"✅ Connected to Ollama with model: {model}")
        except:
            print("❌ Cannot connect to Ollama!")
            raise
    
    def get_rates(self, base="USD") -> Dict:
        """Get exchange rates with caching"""
        if self.cache_time and \
           datetime.now() - self.cache_time < timedelta(hours=1):
            if base in self.rate_cache:
                return self.rate_cache[base]
        
        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{base}"
            response = requests.get(url, timeout=5)
            data = response.json()
            self.rate_cache[base] = data['rates']
            self.cache_time = datetime.now()
            return data['rates']
        except:
            # Fallback
            return {
                "USD": 1.0, "EUR": 0.92, "GBP": 0.79, "JPY": 149.50,
                "CAD": 1.36, "AUD": 1.52, "CHF": 0.88, "CNY": 7.24
            }
    
    def extract_params(self, query: str) -> Dict:
        """Extract conversion parameters using LLM"""
        prompt = f"""Extract currency conversion from: "{query}"

Return JSON: {{"amount": number, "from_currency": "CODE", "to_currency": "CODE"}}
Or multiple targets: {{"amount": number, "from_currency": "CODE", "to_currencies": ["CODE1", "CODE2"]}}

JSON only:"""

        try:
            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options={"temperature": 0.1, "num_predict": 100}
            )
            
            json_match = re.search(r'\{.*\}', response['response'], re.DOTALL)
            if json_match:
                params = json.loads(json_match.group())
                return params
            return None
        except:
            return None
    
    def convert_currency(self, amount: float, from_curr: str, 
                        to_curr: str) -> Tuple[float, float]:
        """Convert between currencies"""
        rates = self.get_rates(from_curr)
        rate = rates.get(to_curr, 0)
        converted = amount * rate
        return converted, rate
    
    def process_message(self, message: str, history: List) -> Tuple[str, List]:
        """
        Process user message and return response
        
        Args:
            message: User's message
            history: Chat history (list of [user_msg, bot_msg] pairs)
            
        Returns:
            Tuple of (empty string, updated history)
        """
        if not message.strip():
            return "", history
        
        # Extract parameters
        params = self.extract_params(message)
        
        if not params or 'error' in params:
            # Try to answer as information query
            prompt = f"""Answer this currency question briefly:

Question: {message}

Answer (2-3 sentences):"""
            
            try:
                response = ollama.generate(
                    model=self.model,
                    prompt=prompt,
                    options={"temperature": 0.3, "num_predict": 200}
                )
                answer = response['response'].strip()
            except:
                answer = "I couldn't understand that. Try asking for a currency conversion like 'Convert 100 USD to EUR'"
            
            history.append((message, answer))
            return "", history
        
        # Perform conversion(s)
        try:
            amount = params['amount']
            from_curr = params['from_currency'].upper()
            
            # Handle single or multiple targets
            if 'to_currencies' in params:
                to_currencies = [c.upper() for c in params['to_currencies']]
            else:
                to_currencies = [params['to_currency'].upper()]
            
            # Build response
            if len(to_currencies) == 1:
                converted, rate = self.convert_currency(amount, from_curr, to_currencies[0])
                answer = f"**{amount} {from_curr}** converts to:\n\n"
                answer += f"💰 **{converted:.2f} {to_currencies[0]}**\n\n"
                answer += f"📊 Exchange rate: 1 {from_curr} = {rate:.4f} {to_currencies[0]}"
            else:
                answer = f"**Converting {amount} {from_curr}:**\n\n"
                for to_curr in to_currencies:
                    converted, rate = self.convert_currency(amount, from_curr, to_curr)
                    answer += f"• **{converted:.2f} {to_curr}** (rate: {rate:.4f})\n"
            
            history.append((message, answer))
            
        except Exception as e:
            error_msg = f"❌ Error: {str(e)}"
            history.append((message, error_msg))
        
        return "", history
    
    def get_quick_rates(self) -> str:
        """Get quick reference rates"""
        try:
            rates = self.get_rates("USD")
            output = "### 💵 Quick Reference Rates (vs USD)\n\n"
            
            major_currencies = {
                "EUR": "🇪🇺 Euro",
                "GBP": "🇬🇧 Pound Sterling",
                "JPY": "🇯🇵 Japanese Yen",
                "CHF": "🇨🇭 Swiss Franc",
                "CAD": "🇨🇦 Canadian Dollar",
                "AUD": "🇦🇺 Australian Dollar"
            }
            
            for code, name in major_currencies.items():
                rate = rates.get(code, 0)
                output += f"**{name}**: 1 USD = {rate:.4f} {code}\n\n"
            
            output += f"\n_Updated: {datetime.now().strftime('%Y-%m-%d %H:%M')}_"
            return output
            
        except:
            return "Could not fetch current rates"
    
    def create_interface(self):
        """Create Gradio interface"""
        
        with gr.Blocks(
            title="Currency Exchange Agent",
            theme=gr.themes.Soft()
        ) as interface:
            
            gr.Markdown("""
            # 💱 Currency Exchange Agent
            ### Powered by Ollama - Local LLM Processing
            
            Ask me to convert currencies in natural language!
            
            **Examples:**
            - Convert 100 USD to EUR
            - How much is 50 euros in dollars and pounds?
            - What's 1000 yen in USD?
            """)
            
            with gr.Row():
                with gr.Column(scale=2):
                    chatbot = gr.Chatbot(
                        label="Chat with Currency Agent",
                        height=500,
                        show_label=True
                    )
                    
                    with gr.Row():
                        msg = gr.Textbox(
                            placeholder="Type your currency question...",
                            label="Your Message",
                            scale=4
                        )
                        send_btn = gr.Button("Send 📤", scale=1)
                    
                    gr.Examples(
                        examples=[
                            "Convert 100 USD to EUR",
                            "How much is 50 GBP in USD and EUR?",
                            "What's 1000 JPY in USD?",
                            "Convert 250 CAD to AUD",
                            "What are the best currencies for travel?"
                        ],
                        inputs=msg,
                        label="Try these examples:"
                    )
                
                with gr.Column(scale=1):
                    gr.Markdown("### ℹ️ Information")
                    
                    rates_display = gr.Markdown(
                        value=self.get_quick_rates()
                    )
                    
                    refresh_btn = gr.Button("🔄 Refresh Rates")
                    
                    gr.Markdown(f"""
                    ---
                    **Model**: {self.model}
                    
                    **Status**: 🟢 Online
                    
                    **Privacy**: All processing happens locally!
                    """)
            
            # Event handlers
            msg.submit(
                self.process_message,
                inputs=[msg, chatbot],
                outputs=[msg, chatbot]
            )
            
            send_btn.click(
                self.process_message,
                inputs=[msg, chatbot],
                outputs=[msg, chatbot]
            )
            
            refresh_btn.click(
                lambda: self.get_quick_rates(),
                outputs=rates_display
            )
        
        return interface


def main():
    """Entry point"""
    import sys
    
    model = sys.argv[1] if len(sys.argv) > 1 else "llama3.2"
    
    print(f"🚀 Starting Web Interface with {model}...")
    
    try:
        agent = CurrencyAgentWeb(model=model)
        interface = agent.create_interface()
        
        print("\n✅ Server starting...")
        print("🌐 Open in browser: http://localhost:7860")
        print("⏹️  Press Ctrl+C to stop\n")
        
        interface.launch(
            server_name="0.0.0.0",
            server_port=7860,
            share=False
        )
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nTroubleshooting:")
        print("1. Install Gradio: pip install gradio")
        print("2. Make sure Ollama is running: ollama serve")
        print(f"3. Pull model: ollama pull {model}")
        sys.exit(1)


if __name__ == "__main__":
    main()
