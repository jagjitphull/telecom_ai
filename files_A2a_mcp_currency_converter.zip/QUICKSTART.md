# ⚡ Quick Start Guide

Get up and running with the Currency Exchange Agent in 5 minutes!

## Prerequisites Check

Before starting, ensure you have:

- ✅ **Python 3.8+** installed
- ✅ **Internet connection** (for installing packages and fetching rates)
- ✅ **5GB free disk space** (for Ollama model)

## 🚀 Installation Methods

### Method 1: Automated Setup (Recommended)

The fastest way - just run one command:

```bash
chmod +x setup.sh
./setup.sh
```

This script will:
1. Check Python installation
2. Install Ollama (if needed)
3. Download the LLM model
4. Create virtual environment
5. Install all dependencies
6. Run tests

**Time**: ~5-10 minutes (depending on download speed)

### Method 2: Manual Setup

If you prefer to do it step-by-step:

#### Step 1: Install Ollama

**Linux:**
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

**macOS:**
```bash
brew install ollama
```

**Windows:**
Download from https://ollama.ai/download

#### Step 2: Start Ollama & Pull Model

```bash
# Start Ollama server (in background or separate terminal)
ollama serve

# In another terminal, pull the model
ollama pull llama3.2
```

#### Step 3: Set Up Python Environment

```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate  # Linux/Mac
# Or on Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 🎯 Your First Currency Conversion

### Option 1: Simple CLI (Best for Beginners)

```bash
python currency_agent_simple.py
```

**Example interaction:**
```
💱 Currency Exchange Agent (Powered by Ollama)

You: Convert 100 USD to EUR

💭 Thinking...

🤖 Agent: 100 USD equals approximately 92.50 EUR at an exchange 
          rate of 0.9250.

You: quit
👋 Goodbye!
```

### Option 2: Multi-Agent System

```bash
python currency_agent_multi.py
```

**Features:**
- Multiple specialized agents
- Conversation history
- More sophisticated responses

**Example:**
```
You: Convert 100 USD to EUR and GBP

🤖 Agent: Converting 100 USD:
          • 92.50 EUR (rate: 0.9250)
          • 79.00 GBP (rate: 0.7900)

You: What's a strong currency?

🤖 Agent: The Swiss Franc (CHF) and Singapore Dollar (SGD) 
          are considered among the strongest currencies due 
          to economic stability...
```

### Option 3: Web Interface (Most User-Friendly)

```bash
python currency_agent_web.py
```

Then open your browser to: **http://localhost:7860**

Features:
- 💬 Chat interface
- 📊 Live rate display
- 🎨 Beautiful UI
- 📱 Mobile-friendly

## 💡 Example Queries

Try these in any of the interfaces:

### Basic Conversions
```
Convert 100 USD to EUR
How much is 50 euros in dollars?
What's 1000 yen in GBP?
```

### Multiple Currencies
```
Convert 100 USD to EUR, GBP, and JPY
How much is 500 CAD in USD and AUD?
```

### Information Questions
```
What are the best currencies for international travel?
Why do exchange rates change?
What's the most stable currency?
```

## 🛠️ Configuration

### Changing the Model

Edit `config.py` or pass as argument:

```python
# In config.py
OLLAMA_MODEL = "mistral"  # Instead of llama3.2
```

Or:
```bash
python currency_agent_simple.py mistral
```

### Available Models

| Model | Size | Speed | Best For |
|-------|------|-------|----------|
| `llama3.2` | 3B | ⚡ Fast | Default choice |
| `mistral` | 7B | ⚡⚡ Medium | Better responses |
| `phi3` | 3.8B | ⚡⚡⚡ Fastest | Limited resources |
| `llama3.1` | 8B | 🐌 Slower | Maximum quality |

### Performance Tuning

For faster responses:

```python
# config.py
OLLAMA_NUM_PREDICT = 256  # Reduce from 512
OLLAMA_MODEL = "phi3"      # Use smaller model
```

For better quality:

```python
# config.py
OLLAMA_NUM_PREDICT = 1024  # Increase tokens
OLLAMA_MODEL = "llama3.1"  # Use larger model
OLLAMA_TEMPERATURE = 0.2   # More focused (0.1-0.3)
```

## 🔍 Troubleshooting

### Issue: "Cannot connect to Ollama"

**Solution:**
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# If not, start it
ollama serve
```

### Issue: "Model not found"

**Solution:**
```bash
# List available models
ollama list

# Pull the required model
ollama pull llama3.2
```

### Issue: "Slow responses"

**Solutions:**
1. Use a smaller model: `phi3` instead of `llama3.2`
2. Reduce output length in config
3. Check system resources (CPU/RAM usage)

### Issue: "Rate limit exceeded"

**Solution:**
The free exchange rate API has limits. The agent caches rates for 1 hour automatically. If you need higher limits, get a free API key from https://www.exchangerate-api.com/

```python
# config.py
EXCHANGE_RATE_API_KEY = "your-key-here"
```

### Issue: "Import errors"

**Solution:**
```bash
# Make sure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

## 📚 Next Steps

### Learn the Architecture
Read `docs/ARCHITECTURE.md` to understand how the system works.

### Customize the Agent
1. Modify prompts in the code
2. Add new agents
3. Integrate new tools

### Build Your Own Features
Ideas to try:
- Add support for cryptocurrencies
- Create rate alerts
- Build a mobile app interface
- Add historical rate charts

### Study the Code
Start with `currency_agent_simple.py` (~200 lines) to understand the basics, then move to the multi-agent system.

## 🎓 Learning Path

**Day 1**: Get it running
- ✅ Install and run simple agent
- ✅ Try various queries
- ✅ Read the simple agent code

**Day 2**: Understand the architecture
- ✅ Read ARCHITECTURE.md
- ✅ Run multi-agent system
- ✅ Study orchestration pattern

**Day 3**: Extend the system
- ✅ Add a new query type
- ✅ Modify a prompt
- ✅ Create a custom agent

**Week 2+**: Build something new
- ✅ Apply patterns to your own project
- ✅ Integrate with other systems
- ✅ Share your creation!

## 🆘 Getting Help

### Documentation
- `README.md` - Overview and features
- `docs/ARCHITECTURE.md` - System design
- `docs/PROMPTS.md` - Prompt engineering guide
- Code comments - Extensive inline documentation

### Common Issues
Most issues are:
1. Ollama not running (`ollama serve`)
2. Model not downloaded (`ollama pull llama3.2`)
3. Wrong Python version (need 3.8+)
4. Virtual environment not activated

### Testing Your Setup

Run this quick test:

```bash
python3 << EOF
import ollama
import requests

# Test 1: Ollama
try:
    ollama.list()
    print("✅ Ollama: OK")
except:
    print("❌ Ollama: NOT RUNNING")

# Test 2: Exchange API
try:
    r = requests.get("https://api.exchangerate-api.com/v4/latest/USD", timeout=5)
    print(f"✅ Exchange API: OK ({r.status_code})")
except:
    print("⚠️  Exchange API: Limited")

print("\nYou're ready to go!")
EOF
```

## 🎉 Success Checklist

You're ready when you can:

- [x] Run `ollama list` and see your model
- [x] Run `python currency_agent_simple.py` without errors
- [x] Ask "Convert 100 USD to EUR" and get a response
- [x] See exchange rates update in real-time

**Congratulations!** You now have a fully functional AI currency agent running locally! 🎊

---

## Quick Reference Commands

```bash
# Setup
./setup.sh                              # Auto setup

# Running
python currency_agent_simple.py         # CLI
python currency_agent_multi.py          # Multi-agent
python currency_agent_web.py            # Web UI (port 7860)

# Ollama
ollama serve                            # Start server
ollama list                             # List models
ollama pull llama3.2                    # Download model
ollama rm llama3.2                      # Remove model

# Environment
source venv/bin/activate                # Activate venv
deactivate                              # Deactivate venv
pip install -r requirements.txt         # Install deps

# Testing
python -m pytest tests/                 # Run tests
python tests/test_agent.py             # Single test
```

---

**Time to First Response**: < 5 minutes with automated setup!

Happy learning! 🚀
